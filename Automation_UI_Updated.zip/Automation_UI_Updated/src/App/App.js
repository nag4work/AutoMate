import React, { Component } from "react";
import { BrowserRouter, Route } from "react-router-dom";
import "./App.css";
import Login from "../pages/login";
import Navigation from "../components/MaterialUi/NavigationMUI";
import { userAuth } from "../redux/actions/index";
import { connect } from "react-redux";
import UserGuide from "../pages/userGuide";
import Logout from "../pages/logout";
import LandingPage from "../pages/details";
import ContactForm from "../pages/Automation/ContactForm";

class Nav extends Component {
  render() {
    return (
      <Navigation history={this.props.history}>
        <Route path="/" exact component={LandingPage}></Route>
        <Route path="/login" exact component={Login}></Route>
        <Route path="/logout" exact component={Logout}></Route>
        <Route path="/userGuide" exact component={UserGuide}></Route>
        <Route path="/contactForm" exact component={ContactForm}></Route>
      </Navigation>
    );
  }
}

class App extends Component {
  componentDidMount() {}

  render() {
    return (
      <React.StrictMode>
        <BrowserRouter>
          <Route to="/" component={Nav} />
        </BrowserRouter>
      </React.StrictMode>
    );
  }
}

const mapStateToProps = (state) => {
  return {
    user: state.user,
    reduxState: state,
  };
};
export default connect(mapStateToProps, { userAuth })(App);
