import axios from "axios";

export const getDepartmentCollection = () => [
  { id: "Oracle", title: "Oracle" },
  { id: "SQL Server", title: "SQL Server" },
  { id: "SYNAPSE", title: "SYNAPSE" },
  { id: "POSTGRES", title: "POSTGRES" },
  { id: "SNOWFLAKE", title: "SNOWFLAKE" },
  { id: "AWS", title: "AWS" },
  { id: "GCP", title: "GCP" },
];
export const getConditions = () => [
  { id: "Equals", title: "Equals" },
  { id: "Not Equals", title: "Not Equals" },
  { id: "Contains", title: "Contains" },
  { id: "Greater Than", title: "Greater Than" },
  { id: "Less Than", title: "Less Than" },
  { id: "Null", title: "Null" },
  { id: "Not Null", title: "Not Null" },
  { id: "Greater Than or equal to", title: "Greater Than or equal to" },
  { id: "Less Than or equal to", title: "Less Than or equal to" },
  { id: "Match with target Query", title: "Match with target Query" },
];

export const getQuerydata = () => [
  { id: "Source Query", title: "Source Query" },
  { id: "Target Query", title: "Target Query" },
];

export const getSQLType = () => [
  { id: "Count", title: "Count" },
  { id: "Compare", title: "Compare" },
];

export async function callbackendService(data) {
  var config = {
    timeout: 8000,
    headers: {
      "Content-Length": 0,
      Accept: "application/json",
      "Content-Type": "text/plain",
    },
  };
  await axios
    .post(
      "https://app-cvpautomation-dev.azurewebsites.net/Automation/UI",
      {
        server_name: data.ServerName,
        port: data.Port,
        database_name: data.DataBaseName,
        db_UName: data.DBUserName,
        db_Password: data.DBPassword,
        db_type: data.DBType,
        sql_type: data.SQLType,
        condition: data.Conditions,
        assertion: data.Asserts,
        source_query: data.SourceQuery,
        target_query: data.TargetQuery,
        email_id: data.email,
      },
      config
    )
    .then((response) => {
      return response.data;
    });
  //alert("Automation request Submitted. Please check your email with results");
  // return await Promise.resolve(1);
}
