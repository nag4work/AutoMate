const defaultValues = {
  filterOptions: {
    regions: [],
    states: [], //localStorageIO("states"),
    rawMakes: [], //localStorageIO("rawMakes"),
    rawModels: [], //localStorageIO("rawModels"),
    rawStyles: [], //localStorageIO("rawStyles"),
    condition: [], //localStorageIO("condition"),
    fico: [],
    income: [],
    rawData: [],
    bandRawData: [], //localStorageIO("rawData"),
  },
};

export default (state = defaultValues, action) => {
  const { type, payload } = action;
  console.log("Type & Payload: Filter Options", type, payload);
  let stateCopy = JSON.parse(JSON.stringify(state));
  switch (type) {
    case "FILTER_OPTIONS":
      stateCopy.filterOptions = payload.filterOptions;
      return stateCopy;
    default:
      return state;
  }
};
