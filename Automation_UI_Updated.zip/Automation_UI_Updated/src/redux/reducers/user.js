const localStorageIO = (key, value) => {
  console.log("user", key, value);
  if (value) {
    const item = {
      value: value,
      expiry: new Date().getTime() + 21600000,
    };

    localStorage.setItem(key, JSON.stringify(item));
  } else if (value === "") {
    const item = {
      value: value,
      expiry: 0,
    };
    //localStorage.setItem(key, value);
    localStorage.setItem(key, JSON.stringify(item));
  } else {
    console.log("Step1: Key", key);
    if (key === "expiry") {
      const getExpiry = localStorage.getItem("username");
      console.log("step: 4 get expiry", getExpiry);
      if (getExpiry === "undefined" || !getExpiry) {
        return "";
      } else {
        const item = JSON.parse(getExpiry);
        console.log("step:5 get expiry", item);
        return new Date().getTime() > item.expiry;
      }
    } else {
      const getResult = localStorage.getItem(key);
      console.log("Step 2: getResult", getResult);
      if (getResult === "undefined" || !getResult) {
        return "";
      } else {
        console.log("Step:3 get result", getResult);
        const item = JSON.parse(getResult);
        if (new Date().getTime() > item.expiry) {
          localStorage.removeItem(key);
          return "";
        }
        return item.value;
      }
    }
  }
};

const defaultValues = {
  id: localStorageIO("id"), // || 38,
  name: localStorageIO("username"), // || "AravindRao Gone",
  email: localStorageIO("emailid"), // || "AravindGone@lithia.com",
  expiry: localStorageIO("expiry"), // || "",
  admin: false,
  user: false,
  login: false,
  logout: false,
};

export default (state = defaultValues, action) => {
  const { type, payload } = action;
  console.log("Type & Payload user info", type, payload);
  let stateCopy = JSON.parse(JSON.stringify(state));
  switch (type) {
    case "USER_AUTH":
      stateCopy.id = payload.id;
      stateCopy.name = payload.name;
      stateCopy.email = payload.email;
      return stateCopy;
    case "SET_OPTIONS":
      stateCopy.id = payload.id;
      stateCopy.name = payload.name;
      stateCopy.email = payload.email;
      stateCopy.login = payload.login;
      stateCopy.logout = payload.logout;
      localStorageIO("id", payload.id);
      localStorageIO("username", payload.name);
      localStorageIO("emailid", payload.email);
      return stateCopy;
    default:
      return state;
  }
};
