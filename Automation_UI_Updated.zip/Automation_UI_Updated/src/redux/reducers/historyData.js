import moment from "moment";

const defaultValues = {
  historyQueryData: [],
  dateRange: [
    moment(Date.now()).subtract(1, "days").format("MM/DD/YYYY"),
    moment(Date.now()).format("MM/DD/YYYY"),
  ],
};

export default (state = defaultValues, action) => {
  const { type, payload } = action;
  let stateCopy = JSON.parse(JSON.stringify(state));
  switch (type) {
    case "HISTORY_QUERY_DATA":
      //stateCopy.historyQueryData = payload.historyQueryData;
      stateCopy.dateRange = payload.dateRange;
      return stateCopy;
    default:
      return state;
  }
};
