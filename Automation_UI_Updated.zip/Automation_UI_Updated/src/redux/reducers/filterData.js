const defaultValues = {
  filterData: [],
  isLoading: false,
};

export default (state = defaultValues, action) => {
  const { type, payload } = action;
  let stateCopy = JSON.parse(JSON.stringify(state));
  switch (type) {
    case "FILTER_DATA":
      stateCopy.filterData = payload.filterData;
      stateCopy.isLoading = payload.isLoading;
      return stateCopy;
    default:
      return state;
  }
};
