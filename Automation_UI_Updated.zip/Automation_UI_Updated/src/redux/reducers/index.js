import { combineReducers } from "redux";

import user from "./user.js";
import metaData from "./metaData.js";
import selectedMetaData from "./selectedMetaData.js";
import filterData from "./filterData.js";
import historyData from "./historyData.js";

const rootReducer = combineReducers({
  user,
  metaData,
  selectedMetaData,
  filterData,
  historyData,
});

export default rootReducer;
