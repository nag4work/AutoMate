 
const defaultValues = {
    selectedFilters: {
        region : null,
        state : null,
        make : null,             
        model : null,
        style : null,
        condition : null,
        fico : null,
        income : null,
        fico_level : null,
        income_level : null,
        sale_price_min : null,
        sale_price_max : null,
        apr_median : null,
        yearOldest : "",
        mileCap : "",
        financedCap : "",
        cashDown : "",
        payCap : "",
        tradeAmt : "",
        paidOffAmt : "",
        zipCode : "",
        stateTax : "",
        dmvFee : ""
    }
  };
  
  export default (state = defaultValues, action = {}) => {
    const { type, payload } = action;
    
    let stateCopy = JSON.parse(JSON.stringify(state));
    switch (type) {
      case "FILTER_OPTIONS_SELECTED":        
        stateCopy.selectedFilters = payload;            
        return stateCopy;
      default:
        return state;
    }
  };
  