export const userAuth = (payload) => {
  return {
    type: "USER_AUTH",
    payload,
  };
};

export const resetHome = (payload) => {
  return {
    type: "RESET_HOME",
    payload,
  };
};

export const filterOptionsAction = (payload) => {
  return {
    type: "FILTER_OPTIONS",
    payload,
  };
};

export const filterOptionsSelectedAction = (payload) => {
  return {
    type: "FILTER_OPTIONS_SELECTED",
    payload,
  };
};

export const filterDataAction = (payload) => {
  return {
    type: "FILTER_DATA",
    payload,
  };
};

export const setFilterOptionsAction = (payload) => {
  return {
    type: "SET_OPTIONS",
    payload,
  };
};

export const setHistoryQueryDataAction = (payload) => {
  return {
    type: "HISTORY_QUERY_DATA",
    payload,
  };
};
