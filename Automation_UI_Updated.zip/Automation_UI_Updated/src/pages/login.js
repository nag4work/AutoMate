import React, { Component } from "react";
import { connect } from "react-redux";
import { withStyles } from "@material-ui/core/styles";
import { userAuth, setFilterOptionsAction } from "../redux/actions/index";
// import { getConfigSettings } from "../Config";
import { PublicClientApplication } from "@azure/msal-browser";
import DrivewayLogo from "./driway.jpg";
import axios from "axios";

const hostUrl = process.env.REACT_APP_HOST ? process.env.REACT_APP_HOST : "";

const styles = (theme) => ({
  root: {
    flexDirection: "column",
    alignItems: "left",
    justifyContent: "left",
    //border: "1px solid red",
    margin: "1rem",
    width: "95%",
    height: "85vh",
    fontFamily: `CircularXXWeb,"Segoe UI","Segoe",Tahoma,Helvetica,Arial,sans-seri`,
  },
  form: {
    width: "430px",
    //margin: "0 auto",
    display: "flex",
    flexDirection: "column",
    background: "white",
    padding: "20px",
    marginTop: "50px",
    borderRadius: "5px",
  },
  textField: {
    display: "flex",
    width: "100%",
    marginBottom: "0.5rem",
  },
});

class Login extends Component {
  constructor(props) {
    super(props);
    this.state = {
      id: "",
      name: "",
      email: "",
      isAuthenticated: false,
    };
  }

  componentDidMount() {
    if (
      this.props.user.name.trim() !== "" ||
      this.props.user.email.trim() !== "" ||
      this.props.user.id !== ""
    ) {
      this.props.history.push("/");
    } else if (
      !this.props.user.login ||
      (this.props.user.login &&
        (this.props.user.name.trim() === "" ||
          this.props.user.email.trim() === "" ||
          this.props.user.id !== ""))
    ) {
      this.login();
    }
  }

  componentDidUpdate(prevProps, prevState) {
    if (
      this.props.user.login &&
      prevProps.user.login !== this.props.user.login
    ) {
      this.login();
    }
  }

  insertUserDetails = (userName, userEmail) => {
    const postObj = {
      userName: userName,
      userEmail: userEmail,
      isAdmin: false,
    };

    axios
      .post("/api/insertUserDetails", postObj)
      .then((result) => {
        console.log("Result User details insert", result);
        const userId = result?.data?.userId;
        if (userId) {
          return userId;
        } else {
          return null;
        }
      })
      .catch((error) => {
        console.log("Error", error.message);
        return null;
      });
  };

  async login() {
    try {
      const payload = {
        client: true,
      };
      let configValues = [
        "d31a3f85-f78b-4b40-bad8-ef2eefae658f",
        "http://localhost:3000",
        "https://login.microsoftonline.com/f1a215ee-6910-4213-aec6-ac36fdca6048",
      ];
      // await axios
      //   .post(`${hostUrl}/api/getConfigData`, payload)
      //   .then((result) => {
      //     configValues =
      //       result.data.length > 0 ? result.data[0].value.split(";") : [];
      //   })
      //   .catch((err) => {
      //     console.log("Error in fetching login config data", err.message);
      //     const detailsObj = {
      //       id: "",
      //       name: "",
      //       email: "",
      //     };
      //     this.props.setFilterOptionsAction(detailsObj);
      //   });

      if (configValues.length > 0) {
        this.publicClientApplication = new PublicClientApplication({
          auth: {
            clientId: configValues[0],
            redirectUri: configValues[1],
            authority: configValues[2],
          },
          cache: {
            cacheLocation: "sessionStorage",
            storeAuthStateInCookie: true,
          },
        });
        let result = await this.publicClientApplication.loginPopup({
          scopes: ["user.read"],
          prompt: "select_account",
        });

        const userName = result.account.name;
        const userEmail = result.account.username;
        //const userId = this.insertUserDetails(userName, userEmail);

        const postObj = {
          userName: userName,
          userEmail: userEmail,
          isAdmin: false,
        };

        const detailsObj = {
          id: 38,
          name: userName,
          email: userEmail,
          login: false,
          logout: false,
        };
        this.props.setFilterOptionsAction(detailsObj);
        this.props.history.push("/");

        // await axios
        //   .post("/api/insertUserDetails", postObj)
        //   .then((res) => {
        //     console.log("res User details insert", res);
        //     const userId = res?.data?.userId;
        //     console.log("User ID", userId);
        //     if (userId) {
        //       this.setState({
        //         isAuthenticated: true,
        //         name: result.account.name,
        //         email: result.account.username,
        //       });
        //       const detailsObj = {
        //         id: userId,
        //         name: userName,
        //         email: userEmail,
        //         login: false,
        //         logout: false,
        //       };
        //       this.props.setFilterOptionsAction(detailsObj);
        //       this.props.history.push("/");
        //     } else {
        //       this.setState({ isAuthenticated: false, name: "", email: "" });
        //       console.log("db failed to provide user id back");
        //       const detailsObj = {
        //         id: "",
        //         name: "",
        //         email: "",
        //       };
        //       this.props.setFilterOptionsAction(detailsObj);
        //     }
        //   })
        //   .catch((error) => {
        //     console.log("Error", error.message);
        //     return null;
        //   });
        //To Do call API nto store user details and get id
      }
    } catch (err) {
      this.setState({ isAuthenticated: false, name: "", email: "" });
      console.log("error at login through azure", err);
      const detailsObj = {
        id: "",
        name: "",
        email: "",
      };
      this.props.setFilterOptionsAction(detailsObj);
    }
  }

  logout() {
    this.publicClientApplication.logoutPopup();
  }

  render() {
    const { classes } = this.props;
    return (
      <div
        style={{
          display: "flex",
          alignItems: "flex-start",
          justifyContent: "center",
          width: "100%",
          height: "90%",
          overflow: "hidden",
          background: "#E5E7E9",
        }}
      >
        <img
          src={DrivewayLogo}
          width="30%"
          height="50%"
          style={{ margin: "auto" }}
        />
      </div>
    );
  }
}

const mstp = (state) => {
  return {
    user: state.user,
    filterData: state.filterData,
  };
};

export default connect(mstp, { userAuth, setFilterOptionsAction })(
  withStyles(styles, { withTheme: true })(Login)
);
