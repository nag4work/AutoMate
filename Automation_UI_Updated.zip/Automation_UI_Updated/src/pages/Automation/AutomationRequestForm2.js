import React, { ActivityIndicator, View, useState } from "react";
import { connect } from "react-redux";
import PropTypes from "prop-types";
import { withStyles } from "@material-ui/core/styles";
import Controls from "../../components/controls/Controls";
import TextField from "@material-ui/core/TextField";
import axios from "axios";
import { Grid } from "@material-ui/core";
import CircularProgress from "@material-ui/core/CircularProgress";
import FormControlLabel from "@material-ui/core/FormControlLabel";
import Checkbox from "@material-ui/core/Checkbox";
import { Button } from "@mui/material";
import DBConfigForm from "./DBConfigForm";

const styles = (theme) => ({
  textField: {
    width: "100%",
    //marginLeft: theme.spacing(1),
    //marginRight: theme.spacing(1),
  },
  dense: {
    marginTop: 16,
  },
  menu: {
    width: 1300,
  },
  button: {
    margin: theme.spacing.fullWidth,
  },
  progress: {
    margin: theme.spacing.unit * 25,
    marginLeft: theme.spacing * 50,
    marginRight: theme.spacing * 10,
    left: "23%",
    position: "absolute",
    top: "14vh",
  },
  gridContainer: {
    marginBottom: "1rem",
  },
});

const initialFValues = {
  Port: 0,
  serverName: "",
  DataBaseName: "",
  DBUserName: "",
  DBPassword: "",
  DBType: "",
  Query: "",
  SQLType: "",
  Conditions: "",
  Asserts: "",
  SourceQuery: "",
  date: "",
  time: "",
  jobtype: "",
  TestCaseID: "",
  hireDate: new Date(),
  isPermanent: false,
};

const DBType = [
  { value: "Select", label: "Select.." },
  { value: "LogDBSqLServer", label: "LogDBSqLServer" },
  { value: "MaxDigitalSnowFlakeDB", label: "MaxDigitalSnowFlakeDB" },
];

const SQLType = [
  { value: "Select", label: "Select.." },
  { value: "Count", label: "Count" },
  { value: "Compare", label: "Compare" },
];
const Conditions = [
  { value: "Select", label: "Select.." },
  { value: "Equals", label: "Equals" },
  { value: "Not Equals", label: "Not Equals" },
  { value: "Contains", label: "Contains" },
  { value: "Greater Than", label: "Greater Than" },
  { value: "Less Than", label: "Less Than" },
  { value: "Null", label: "Null" },
  { value: "Not Null", label: "Not Null" },
  { value: "Greater Than or equal to", label: "Greater Than or equal to" },
  { value: "Less Than or equal to", label: "Less Than or equal to" },
  { value: "Match with target Query", label: "Match with target Query" },
];

class OutlinedTextFields extends React.Component {
  state = {
    currencies: ["Select"],
    DBConfigID: "",
    SQLType: "",
    Conditions: "",
    Asserts: "12",
    SourceQuery: "",
    TargetQuery: "",
    TestCaseID: "",
    email: "@lithia.com",
    SnowFlakeRole: "",
    SNOWFlake_DB_warehouse: "",
    loading: false,
    userGuide: "",
    dbConfigSubmitted: true,
    snowflakefields: false,
  };

  resetForm = () => {
    this.setState({
      SQLType: "",
      Conditions: "",
      Asserts: "",
      SourceQuery: "",
      TargetQuery: "",
      TestCaseID: "",
      email: "@lithia.com",
      submitClicked: false,
    });
  };

  componentDidMount() {
    this.setState({ email: this.props.user.email });
    var config = {
      headers: {
        Accept: "application/json",
        "Content-Type": "text/plain",
      },
    };

    axios
      .post(
        "https://app-cvpautomation-dev.azurewebsites.net/Automation/DBConfigDropDown",
        config
      )
      .then((response) => {
        console.log(response.data);
        this.setState({ currencies: response.data });
        return response.data;
      })
      .catch((error) => {
        console.log(error);
      });
  }

  handleChange = (name) => (event) => {
    this.setState({ [name]: event.target.value });
  };

  handleServerChange = (event) => {
    console.log(
      "event",
      event.target.name,
      event.target.value,
      event.target.id
    );
    this.setState({ [event.target.name]: event.target.value });
  };

  Snowflakehandler = () => {
    console.log("snowflaje");
    if (this.state.DBType === "SNOWFLAKE") {
      this.setState({ snowflakefields: true });
    } else {
      this.setState({ snowflakefields: false });
    }
  };

  DBsubmitHandler = () => {
    if (this.state.serverName === "") alert("serverName field is required.");
    else if (this.state.Port === "") alert("Port field is required.");
    else if (this.state.DataBaseName === "")
      alert("DataBaseName field is required.");
    else if (this.state.DBUserName === "")
      alert("DBUserName field is required.");
    else if (this.state.DBPassword === "")
      alert("DBPassword field is required.");
    else if (this.state.DBType === "") alert("DBType field is required.");
    else {
      if (this.state.DBType === "SNOWFLAKE") {
        if (this.state.SnowFlakeRole === "")
          alert("SnowFlakeRole field is required.");
        else if (this.state.SNOWFlake_DB_warehouse === "")
          alert("Snow Flake WareHouse field is required.");
      } else {
        console.log("dbconfig submitted");
        this.setState({ dbConfigSubmitted: true });
      }
    }
  };

  handleSave = (e) => {
    e.preventDefault();

    this.setState({ submitClicked: true });

    if (
      this.state.Asserts &&
      this.state.Asserts !== "" &&
      this.state.SQLType &&
      this.state.SQLType !== "" &&
      this.state.Conditions &&
      this.state.Conditions !== "" &&
      this.state.SourceQuery &&
      this.state.SourceQuery !== ""
    ) {
      const postObject = {
        configid: this.state.DBConfigID,
        sql_type: this.state.SQLType,
        condition: this.state.Conditions,
        assertion: this.state.Asserts,
        testcaseid: this.state.TestCaseID,
        source_query: this.state.SourceQuery,
        target_query: this.state.TargetQuery,
        email_id: this.state.email,
        save: true,
      };
      var config = {
        headers: {
          Accept: "application/json",
          "Content-Type": "text/plain",
        },
      };

      this.setState({ loading: true });
      alert("Your Request is Saving.");

      axios
        .post(
          "https://app-cvpautomation-dev.azurewebsites.net/Automation/UI",
          postObject,
          config
        )
        .then((response) => {
          if (response.status === 200) {
            alert("Test Case Saved");
            this.setState({ loading: false });
            console.log(response.status);
            console.log(response.data);
          } else if (response.status === 202) {
            alert(response.data);
            console.log(response.status);
            console.log(response.data);
            this.setState({ loading: false });
          } else {
            alert(response.data);
            console.log(response.status);
            console.log(response.data);
            this.setState({ loading: false });
          }
        })
        .catch((error) => {
          alert("Request Failed. Please check your input or Contact Admin");
          this.setState({ loading: false });
          console.log("maja1");
          console.log(error);
        });
    }
  };

  submitHandler = (e) => {
    e.preventDefault();

    this.setState({ submitClicked: true });

    if (
      this.state.Asserts &&
      this.state.Asserts !== "" &&
      this.state.SQLType &&
      this.state.SQLType !== "" &&
      this.state.Conditions &&
      this.state.Conditions !== "" &&
      this.state.SourceQuery &&
      this.state.SourceQuery !== ""
    ) {
      const postObject = {
        configid: this.state.DBConfigID,
        sql_type: this.state.SQLType,
        condition: this.state.Conditions,
        assertion: this.state.Asserts,
        testcaseid: this.state.TestCaseID,
        source_query: this.state.SourceQuery,
        target_query: this.state.TargetQuery,
        email_id: this.state.email,
        save: false,
      };
      var config = {
        headers: {
          Accept: "application/json",
          "Content-Type": "text/plain",
        },
      };

      this.setState({ loading: true });
      alert("Your Request is submitting. The request may longer time sometime. Please wait until the Request complete or close the browser");

      axios
        .post(
          "https://app-cvpautomation-dev.azurewebsites.net/Automation/UI",
          //"http://localhost:8080/Automation/UI",
          postObject,
          config
        )
        .then((response) => {
          if (response.status === 200) {
            alert("Execution Completed. Please check your email with results");
            this.setState({ loading: false });
            console.log(response.status);
            console.log(response.data);
          } else if (response.status === 202) {
            alert(response.data);
            console.log(response.status);
            console.log(response.data);
            this.setState({ loading: false });
          } else {
            alert(response.data);
            console.log(response.status);
            console.log(response.data);
            this.setState({ loading: false });
          }
        })
        .catch((error) => {
          alert("Request Failed. Please check your input or Contact Admin");
          this.setState({ loading: false });
          console.log("maja1");
          console.log(error);
        });
    }
  };

  render() {
    const { classes } = this.props;
    const { loading, userGuide, dbConfigSubmitted, snowflakefields } =
      this.state;

    return (
      <div>
        {dbConfigSubmitted && (
          <form
            //className={classes.container}
            noValidate
            autoComplete="off"
            onSubmit={this.submitHandler}
          >
            <div className={classes.root}>
              {loading && (
                <CircularProgress
                  className={classes.progress}
                  size={200}
                  marginLeft="40%"
                  color="secondary"
                />
              )}
            </div>

            <Grid container spacing={2} className={classes.gridContainer}>
              <Grid item xl={3} lg={3} md={4} sm={6} xs={12}>
                <TextField
                  required
                  id="outlined-select-DBConfigID"
                  select
                  label="DB Connection Name"
                  className={classes.textField}
                  name="DBConfigID"
                  value={this.state.DBConfigID}
                  onChange={this.handleServerChange}
                  SelectProps={{
                    native: true,
                    MenuProps: { className: classes.menu },
                  }}
                  margin="normal"
                  variant="outlined"
                  error={
                    this.state.submitClicked &&
                    (this.state.DBConfigID === "" || !this.state.DBConfigID)
                  }
                  helperText={
                    this.state.submitClicked &&
                    (this.state.DBConfigID === "" || !this.state.DBConfigID) &&
                    "DB Config is required"
                  }
                >
                  {this.state.currencies.map((currency) => (
                    <option key={currency} value={currency}>
                      {currency}
                    </option>
                  ))}
                </TextField>
              </Grid>
              <Grid item xl={3} lg={3} md={4} sm={6} xs={12}>
                <TextField
                  required
                  id="outlined-select-SQL-Type"
                  select
                  label="SQL Type"
                  className={classes.textField}
                  name="SQLType"
                  value={this.state.SQLType}
                  onChange={this.handleServerChange}
                  SelectProps={{
                    native: true,
                    MenuProps: { className: classes.menu },
                  }}
                  margin="normal"
                  variant="outlined"
                  error={
                    this.state.submitClicked &&
                    (this.state.SQLType === "" || !this.state.SQLType)
                  }
                  helperText={
                    this.state.submitClicked &&
                    (this.state.SQLType === "" || !this.state.SQLType) &&
                    "SQL Type is required"
                  }
                >
                  {SQLType.map((option) => (
                    <option key={option.value} value={option.value}>
                      {" "}
                      {option.label}{" "}
                    </option>
                  ))}
                </TextField>
              </Grid>
              <Grid item xl={3} lg={3} md={4} sm={6} xs={12}>
                <TextField
                  required
                  id="outlined-select-Conditions"
                  select
                  label="Conditions"
                  className={classes.textField}
                  name="Conditions"
                  value={this.state.Conditions}
                  onChange={this.handleServerChange}
                  SelectProps={{
                    native: true,
                    MenuProps: { className: classes.menu },
                  }}
                  margin="normal"
                  variant="outlined"
                  error={
                    this.state.submitClicked &&
                    (this.state.Conditions === "" || !this.state.Conditions)
                  }
                  helperText={
                    this.state.submitClicked &&
                    (this.state.Conditions === "" || !this.state.Conditions) &&
                    "Conditions is required"
                  }
                >
                  {Conditions.map((option) => (
                    <option key={option.value} value={option.value}>
                      {" "}
                      {option.label}{" "}
                    </option>
                  ))}
                </TextField>
              </Grid>
              <Grid item xl={3} lg={3} md={4} sm={6} xs={12}>
                <TextField
                  required
                  id="outlined-assertion"
                  label="Assertion"
                  name="Asserts"
                  value={this.state.Asserts}
                  className={classes.textField}
                  margin="normal"
                  variant="outlined"
                  onChange={this.handleServerChange}
                  error={
                    this.state.submitClicked &&
                    (this.state.Asserts === "" || !this.state.Asserts)
                  }
                  helperText={
                    this.state.submitClicked &&
                    (this.state.Asserts === "" || !this.state.Asserts) &&
                    "Assertion is required"
                  }
                />
              </Grid>
              <Grid item xl={3} lg={3} md={4} sm={6} xs={12}>
                <TextField
                  id="outlined-testCaseID"
                  label="Test Case ID"
                  name="TestCaseID"
                  value={this.state.TestCaseID.trim()}
                  className={classes.textField}
                  placeholder="Enter Unique test case name without Space"
                  margin="normal"
                  variant="outlined"
                  onChange={this.handleServerChange}
                />
              </Grid>
              <Grid item xl={3} lg={3} md={4} sm={6} xs={12}>
                <TextField
                  required
                  id="outlined-email-input"
                  label="Email"
                  name="email"
                  value={this.state.email}
                  className={classes.textField}
                  type="email"
                  autoComplete="email"
                  margin="normal"
                  variant="outlined"
                  onChange={this.handleServerChange}
                  error={
                    this.state.submitClicked &&
                    (this.state.email === "" || !this.state.email)
                  }
                  helperText={
                    this.state.submitClicked &&
                    (this.state.email === "" || !this.state.email) &&
                    "Email is required"
                  }
                />
              </Grid>
            </Grid>
            <Grid container spacing={1} className={classes.gridContainer}>
              <Grid item xl={6} lg={6} md={6} sm={12} xs={12}>
                <TextField
                  required
                  id="outlined-SourceQuery"
                  label="Source Query to execute"
                  name="SourceQuery"
                  value={this.state.SourceQuery}
                  multiline
                  maxRows="14"
                  minRows="3"
                  placeholder="Source Query"
                  fullWidth
                  margin="normal"
                  variant="outlined"
                  InputLabelProps={{ shrink: true }}
                  onChange={this.handleServerChange}
                  error={
                    this.state.submitClicked &&
                    (this.state.SourceQuery === "" || !this.state.SourceQuery)
                  }
                  helperText={
                    this.state.submitClicked &&
                    (this.state.SourceQuery === "" ||
                      !this.state.SourceQuery) &&
                    "Source Query is required"
                  }
                />
              </Grid>
              {this.state.Conditions === "Match with target Query" && (
                <Grid item xl={6} lg={6} md={6} sm={12} xs={12}>
                  <TextField
                    id="outlined-TargetQuery"
                    label="Target Query to execute"
                    name="TargetQuery"
                    value={this.state.TargetQuery}
                    multiline
                    maxRows="14"
                    minRows="3"
                    placeholder="Target Query"
                    fullWidth
                    margin="normal"
                    variant="outlined"
                    InputLabelProps={{ shrink: true }}
                    onChange={this.handleServerChange}
                  />
                </Grid>
              )}
            </Grid>
            <div
              style={{
                display: "flex",
                alignItems: "center",
                justifyContent: "flex-end",
                width: "100%",
              }}
            >
              <Button
                type="submit"
                text="Submit"
                variant="contained"
                style={{
                  marginLeft: "1rem",
                  backgroundColor: "#1451B5",
                  color: "#fff",
                  borderRadius: "64px",
                }}
                disabled={loading}
                // onClick={this.handleSearch}
              >
                Submit
              </Button>

              <Button
                type="save"
                text="Save"
                variant="contained"
                style={{
                  marginLeft: "1rem",
                  backgroundColor: "#1451B5",
                  color: "#fff",
                  borderRadius: "64px",
                }}
                disabled={loading}
                onClick={this.handleSave}
              >
                Save
              </Button>

              <Button
                variant="contained"
                style={{
                  marginLeft: "1rem",
                  backgroundColor: "gray",
                  color: "#fff",
                  borderRadius: "64px",
                }}
                type="reset"
                text="Reset"
                onClick={this.resetForm}
                disabled={loading}
              >
                Reset
              </Button>
            </div>
          </form>
        )}
      </div>
    );
  }
}

OutlinedTextFields.propTypes = {
  classes: PropTypes.object.isRequired,
};

const mstp = (state) => {
  return {
    user: state.user,
  };
};

export default connect(mstp, {})(withStyles(styles)(OutlinedTextFields));
