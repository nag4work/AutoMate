import React from "react";
import PropTypes from "prop-types";
import { withStyles } from "@material-ui/core/styles";
//import Controls from "../components/controls/Controls";
import TextField from "@material-ui/core/TextField";
import axios from "axios";
import CircularProgress from "@material-ui/core/CircularProgress";
import { Box } from "@material-ui/core";
import { Grid } from "@material-ui/core";
import { Button } from "@mui/material";

const styles = (theme) => ({
  textField: {
    width: "100%",
    //marginLeft: theme.spacing(1),
    //marginRight: theme.spacing(1),
  },
  dense: {
    marginTop: 16,
  },
  menu: {
    width: 1300,
  },
  button: {
    margin: theme.spacing.fullWidth,
  },
  progress: {
    margin: theme.spacing.unit * 25,
    marginLeft: theme.spacing * 50,
    marginRight: theme.spacing * 10,
    left: "23%",
    position: "absolute",
    top: "2vh",
  },
  gridContainer: {
    marginBottom: "1rem",
  },
  container: {
    marginTop: "1rem",
    padding: "1rem",
  },
});

class OutlinedTextFields extends React.Component {
  state = {
    message: "",
    PhoneNumber: "",
    email: "@lithia.com",
    Name: "",
    loading: false,
    userGuide: "",
  };

  resetForm = () => {
    this.setState({
      env: "",
      PhoneNumber: "",
      email: "@lithia.com",
      Name: "1",
    });
  };

  handleChange = (name) => (event) => {
    this.setState({ [name]: event.target.value });
  };

  handleServerChange = (event) => {
    console.log(
      "event",
      event.target.name,
      event.target.value,
      event.target.id
    );
    this.setState({ [event.target.name]: event.target.value });
  };

  submitHandler = (e) => {
    e.preventDefault();

    if (this.state.message === "") alert("message field is required.");
    else if (this.state.PhoneNumber === "")
      alert("PhoneNumber field is required.");
    else if (this.state.Name === "") alert("Name field is required.");
    else if (this.state.email === "") alert("email field is required.");
    else {
      console.log("Values submit handler", this.state);
      const postObject = {
        message: this.state.message,
        phoneNumber: this.state.PhoneNumber,
        email_id: this.state.email,
        name: this.state.Name,
      };
      var config = {
        headers: {
          Accept: "application/json",
          "Content-Type": "text/plain",
        },
      };

      this.setState({ loading: true });
      alert(
        "Your Request is submitting. You can wait until the Request complete or close the browser"
      );

      axios
        .post(
          "https://app-cvpautomation-dev.azurewebsites.net/Automation/UI/Contact",
          postObject,
          config
        )
        .then((response) => {
          if (response.status === 200) {
            alert("Execution Completed. Please check your email with results");
            this.setState({ loading: false });
            console.log(response.status);
          } else {
            alert("Request Failed. Please check your input or Contact Admin");
            console.log(response.status);
            this.setState({ loading: false });
          }
        })
        .catch((error) => {
          alert("Request Failed. Please check your input or Contact Admin");
          this.setState({ loading: false });
          console.log(error);
        });
    }
  };

  render() {
    const { classes } = this.props;
    const { loading, userGuide } = this.state;

    return (
      <form
        className={classes.container}
        noValidate
        autoComplete="off"
        onSubmit={this.submitHandler}
      >
        <div className={classes.root}>
          {loading && (
            <CircularProgress
              className={classes.progress}
              size={200}
              marginLeft="40%"
              color="secondary"
            />
          )}
        </div>
        <Grid container spacing={2} className={classes.gridContainer}>
          <Grid item xl={3} lg={3} md={4} sm={6} xs={12}>
            <TextField
              required
              id="outlined-DBRowsStart"
              name="Name"
              label="Name"
              value={this.state.Name}
              className={classes.textField}
              variant="outlined"
              onChange={this.handleServerChange}
            />
          </Grid>
          <Grid item xl={3} lg={3} md={4} sm={6} xs={12}>
            <TextField
              id="outlined-DBRowsEnd"
              name="PhoneNumber"
              label="Phone Number"
              value={this.state.PhoneNumber}
              className={classes.textField}
              variant="outlined"
              onChange={this.handleServerChange}
            />
          </Grid>
          <Grid item xl={3} lg={3} md={4} sm={6} xs={12}>
            <TextField
              required
              id="outlined-email-input"
              label="Your Email ID"
              name="email"
              value={this.state.email}
              className={classes.textField}
              type="email"
              autoComplete="email"
              variant="outlined"
              onChange={this.handleServerChange}
            />
          </Grid>
        </Grid>
        <Grid container spacing={2} className={classes.gridContainer}>
          <Grid item xl={12} lg={12} md={12} sm={12} xs={12}>
            <TextField
              required
              id="outlined-SourceQuery"
              label="Message"
              name="message"
              value={this.state.message}
              className={classes.textField}
              multiline
              maxRows={10}
              placeholder="Enter your Message"
              fullWidth
              variant="outlined"
              InputLabelProps={{ shrink: true }}
              onChange={this.handleServerChange}
            />
          </Grid>
        </Grid>
        <div
          style={{
            display: "flex",
            alignItems: "center",
            justifyContent: "flex-end",
            width: "100%",
          }}
        >
          <Button
            type="submit"
            text="Submit"
            variant="contained"
            style={{
              marginLeft: "1rem",
              backgroundColor: "#1451B5",
              color: "#fff",
              borderRadius: "64px",
            }}
            disabled={loading}
            // onClick={this.handleSearch}
          >
            Submit
          </Button>

          <Button
            variant="contained"
            style={{
              marginLeft: "1rem",
              backgroundColor: "gray",
              color: "#fff",
              borderRadius: "64px",
            }}
            type="reset"
            text="Reset"
            onClick={this.resetForm}
            disabled={loading}
          >
            Reset
          </Button>
        </div>
        {/* <div style={{ margin: "auto", marginTop: "20px" }}>
          <div className={classes.root}>
            {!loading ? (
              <Controls.Button type="submit" text="Submit" />
            ) : (
              <div></div>
            )}
            {!loading ? (
              <Controls.Button
                type="reset"
                text="Reset"
                onClick={this.resetForm}
              />
            ) : (
              <div></div>
            )}
          </div>
        </div>         */}
      </form>
    );
  }
}

OutlinedTextFields.propTypes = {
  classes: PropTypes.object.isRequired,
};

export default withStyles(styles)(OutlinedTextFields);
