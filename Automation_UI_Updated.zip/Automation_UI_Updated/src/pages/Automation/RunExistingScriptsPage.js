import React from 'react'
//import EmployeeForm from "./AutomationRequestForm";
import EmployeeForm from "./RunExistingScriptsForm";

//import PageHeader from "../../components/PageHeader";
//import PeopleOutlineTwoToneIcon from '@material-ui/icons/PeopleOutlineTwoTone';
import { Paper,makeStyles } from '@material-ui/core';

const useStyles = makeStyles(theme => ({
    pageContent: {
        width: "100%",
        height: "100%",
    }
}))

export default function Employees() {

    const classes = useStyles();

    return (
        <>
            <Paper className={classes.pageContent}>
                <EmployeeForm />
            </Paper>
        </>
    )
}
