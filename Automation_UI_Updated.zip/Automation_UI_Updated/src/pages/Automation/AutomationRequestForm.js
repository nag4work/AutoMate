//import React, { useState, useEffect } from 'react'
import React from 'react'
import { Grid, } from '@material-ui/core';
import Controls from "../../components/controls/Controls";
import { useForm, Form } from '../../components/useForm';
//import TextField from '@material-ui/core/TextField';
import * as AutomationService from "../../services/AutomationService";

//<Controls.Select name="Query" label="Query" value={values.Query} onChange={handleInputChange} options={AutomationService.getQuerydata()}   error={errors.Query}/>
                  


const initialFValues = {
    Port: 0,
    ServerName: '',
    DataBaseName: '',
    DBUserName: '',
    DBPassword: '',
    DBType: '',
    Query: '',
    SQLType: '',
    Conditions: '',
    Asserts: '',
    SourceQuery: '',
    hireDate: new Date(),
    isPermanent: false,
    
}

export default function EmployeeForm() {
    console.info("Program Started");

    const validate = (fieldValues = values) => {
        let temp = { ...errors }
        if ('ServerName' in fieldValues)
            temp.ServerName = fieldValues.ServerName ? "" : "This field is required."
        if ('Port' in fieldValues)
            temp.Port = fieldValues.Port ? "" : "This field is required."
        if ('DataBaseName' in fieldValues)
            temp.DataBaseName = fieldValues.DataBaseName ? "" : "This field is required."
        if ('DBUserName' in fieldValues)
            temp.DBUserName = fieldValues.DBUserName ? "" : "This field is required."
        if ('DBPassword' in fieldValues)
            temp.DBPassword = fieldValues.DBPassword ? "" : "This field is required."
        if ('DBType' in fieldValues)
            temp.DBType = fieldValues.DBType ? "" : "This field is required."
        if ('Query' in fieldValues)
            temp.Query = fieldValues.Query ? "" : "This field is required."
        if ('SQLType' in fieldValues)
            temp.SQLType = fieldValues.SQLType ? "" : "This field is required."
        if ('Conditions' in fieldValues)
            temp.Conditions = fieldValues.Conditions ? "" : "This field is required."
             
        if ('Asserts' in fieldValues)
            temp.Asserts =  fieldValues.Asserts || fieldValues.TargetQuery? "" : "Please enter target query or assertion field."
            //temp.Asserts =  fieldValues.TargetQuery? "" : "Please enter target query if Asserts is blank."

        if ('SourceQuery' in fieldValues)
            temp.SourceQuery = fieldValues.SourceQuery ? "" : "This field is required."
        if ('email' in fieldValues)
            temp.email = fieldValues.email ? "" : "This field is required."
        
            
     

        setErrors({
            ...temp
        })

        if (fieldValues === values)
            return Object.values(temp).every(x => x === "")
    }
    
    const {
        values,
        errors,
        setErrors,
        handleInputChange,
        resetForm
    } = useForm(initialFValues, true, validate);

    const handleSubmit = e => {
        e.preventDefault()
        //if (validate()) {
            console.log('values');
              AutomationService.callbackendService(values).then(res => {

                if(res.status === 200){
                    alert("Automation request Submitted. Please check your email with results");
                    console.log(res.status)
                } 
                
            })

           
            //alert("Automation request Submitted. Please check your email with results");
            //resetForm()
      // }
    }

    return (
        <Form onSubmit={handleSubmit} >



            <Grid container>
                
                <Grid item xs={5}>
                    
                    <Controls.Input name="ServerName" label="Server Name" value={values.ServerName} onChange={handleInputChange} error={errors.ServerName} />
                    <Controls.Input label="Port" name="Port" value={values.Port} onChange={handleInputChange} error={errors.Port} />
                    <Controls.Input label="DataBase Name" name="DataBaseName" value={values.DataBaseName} onChange={handleInputChange} error={errors.DataBaseName}  />
                    <Controls.Input label="DataBase UserName" name="DBUserName" value={values.DBUserName} onChange={handleInputChange}  error={errors.DBUserName} />
                    <Controls.Input label="DataBase Password" disabled="true" name="DBPassword" value={values.DBPassword} onChange={handleInputChange} error={errors.DBPassword} />
                    <Controls.Select  name="DBType" label="DataBase Type" value={values.DBType}  onChange={handleInputChange} options={AutomationService.getDepartmentCollection()} error={errors.DBType} />
                </Grid>

                <Grid item xs={5}>
                    <Controls.Select name="SQLType" label="SQL Type" value={values.SQLType} onChange={handleInputChange} options={AutomationService.getSQLType()} error={errors.SQLType} />
                    <Controls.Select name="Conditions" label="Conditions" value={values.Conditions} onChange={handleInputChange} options={AutomationService.getConditions()} error={errors.Conditions} />
                    <Controls.Input label="Assertion?" name="Asserts" value={values.Asserts} onChange={handleInputChange} error={errors.Asserts} />
                    <Controls.Input label="Source Query to execute" name="SourceQuery" value={values.SourceQuery}  onChange={handleInputChange} error={errors.SourceQuery}  />
                    <Controls.Input label="Target Query to execute" name="TargetQuery" value={values.TargetQuery} onChange={handleInputChange} />
                    <Controls.Input label="Email to get Results" name="email" value={values.email} onChange={handleInputChange} error={errors.SourceQuery} />

                    <div>
                        <Controls.Button type="submit" text="Submit" />
                        <Controls.Button text="Reset" color="default" onClick={resetForm} />
                    </div>
                </Grid>

            </Grid>
        </Form>
    )
}
