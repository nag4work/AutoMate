import React from "react";
import PropTypes from "prop-types";
import classNames from "classnames";
import { withStyles } from "@material-ui/core/styles";
import MenuItem from "@material-ui/core/MenuItem";
import Controls from "../../components/controls/Controls";
import TextField from "@material-ui/core/TextField";
import { useForm, Form } from "../../components/useForm";
import * as AutomationService from "../../services/AutomationService";
import axios from "axios";
import CircularProgress from "@material-ui/core/CircularProgress";
import { Grid } from "@material-ui/core";
import { Button } from "@mui/material";
import Checkbox from "@mui/material/Checkbox";
import FormControlLabel from "@mui/material/FormControlLabel";
import { connect } from "react-redux";

const styles = (theme) => ({
  textField: {
    width: "100%",
    //marginLeft: theme.spacing(1),
    //marginRight: theme.spacing(1),
  },
  dense: {
    marginTop: 16,
  },
  menu: {
    width: 1300,
  },
  button: {
    margin: theme.spacing.fullWidth,
  },
  progress: {
    margin: theme.spacing.unit * 25,
    marginLeft: theme.spacing * 50,
    marginRight: theme.spacing * 10,
    left: "23%",
    position: "absolute",
    top: "2vh",
  },
  gridContainer: {
    marginBottom: "1rem",
  },
});

const TestScripts = [
  { value: "Select", label: "Select.." },
  { value: "Smoke", label: "Smoke execution" },
  { value: "DSDecisionsAPI_Val", label: "ICO and Estimates" },
  { value: "Val_CacheServices_count", label: "Cache Services" },
  {
    value: "Val_maxDigital_hourly_testcases",
    label: "Max Digital Hourly test case",
  },
  {
    value: "Val_maxDigital_Daily_testcases",
    label: "Max Digital Hourly daily case",
  },
  {
    value: "Val_maxDigital_post_Processing_Advisory_Alerts",
    label: "Max Digital Post Processing Advisory Alerts",
  },
  {
    value: "Val_Failure_warning_Summaries_Report",
    label: "Max Digital failure warning summary report",
  },
  { value: "CPIData_Val", label: "Daily Monitoring" },
  { value: "APIMonitoring_Val", label: "API Daily Monitoring " },
  {
    value: "Get_No_Price_Disposition_Vehicle_Details_Val",
    label: "no price disposition vehicle details",
  },
  {
    value: "Get_Missing_VINs_From_DriveWay_Table",
    label: "missing Vins from driveway table",
  },
  { value: "Get_edilogs_error_status", label: "edi error log execution" },
];
const env = [
  { value: "Select", label: "Select.." },
  { value: "DEV", label: "DEV" },
  { value: "UAT", label: "UAT" },
  { value: "PROD", label: "PROD" },
];

const JobType = [
  { value: "NoRepeat", label: "NoRepeat" },
  { value: "Daily", label: "Daily" },
  { value: "Weekly", label: "Weekly" },
  { value: "Monthly", label: "Monthly" },
  { value: "Yearly", label: "Yearly" },
];

class OutlinedTextFields extends React.Component {
  state = {
    currencies: [],
    Connections: [],
    env: "",
    TestScripts: "",
    email: "@lithia.com",
    DBRowsStart: "1",
    DBRowsEnd: "",
    loading: false,
    userGuide: "",
    checked: false,
    date:"",
    time: "",
    jobtype: "",
  };

  resetForm = () => {
    this.setState({
      env: "",
      TestScripts: "",
      email: "@lithia.com",
      DBRowsStart: "1",
      DBRowsEnd: "",
      checked: false,
    });
  };

  componentDidMount() {
    this.setState({ email: this.props.user.email });
    var config = {
      headers: {
        Accept: "application/json",
        "Content-Type": "text/plain",
      },
    };

    axios
      .post(
        "https://app-cvpautomation-dev.azurewebsites.net/Automation/testCaseDropDown",
        //"http://localhost:8080/Automation/testCaseDropDown",
        config
      )
      .then((response) => {
        console.log(response.data);
        this.setState({ currencies: response.data });
        return response.data;
      })
      .catch((error) => {
        console.log(error);
      });
  }

  handleServerTestChange = (event) => {
    this.setState({ [event.target.name]: event.target.value });
    var config = {
      headers: {
        Accept: "application/json",
        "Content-Type": "text/plain",
      },
    };

    axios
      .post(
        "https://app-cvpautomation-dev.azurewebsites.net/Automation/testCaseConnectionDropDown",
        event.target.value,
        //"http://localhost:8080/Automation/testCaseConnectionDropDown", event.target.value,
        config
      )
      .then((response) => {
        console.log(response.data);
        this.setState({ Connections: response.data });
        return response.data;
      })
      .catch((error) => {
        console.log(error);
      });
  };

  handleChange = (event) => {
    this.setState({ checked: !this.state.checked });
  };

  handleServerChange = (event) => {
    console.log(
      "event",
      event.target.name,
      event.target.value,
      event.target.id
    );
    this.setState({ [event.target.name]: event.target.value });
  };

  submitHandler = (e) => {
    e.preventDefault();

    if (this.state.TestScripts === "") alert("TestScripts field is required.");
    else if (this.state.env === "") alert("Connection Name field is required.");
    else if (this.state.DBRowsStart === "")
      alert("DBRowsStart field is required.");
    else {
      console.log("Values submit handler", this.state);
      const postObject = {
        testCase_ID: this.state.TestScripts,
        env: this.state.env,
        email_id: this.state.email,
        date:this.state.date,
        time:this.state.time,
        repeat:this.state.jobtype,
        checked:this.state.checked,
        
      };
      var config = {
        headers: {
          Accept: "application/json",
          "Content-Type": "text/plain",
        },
      };

      this.setState({ loading: true });
      alert("Your Request is submitting.");

      axios
        .post(
          //"https://app-cvpautomation-dev.azurewebsites.net/Automation/UI/runscripts",
          "http://localhost:8080/Automation/UI/runscripts",
          postObject,
          config
        )
        .then((response) => {
          if (response.status === 200) {
            alert(response.data);
            this.setState({ loading: false });
            console.log(response.status);
          } else {
            alert("Request Failed. Please check your input or Contact Admin");
            console.log(response.status);
            this.setState({ loading: false });
          }
        })
        .catch((error) => {
          alert("Request Failed. Please check your input or Contact Admin");
          this.setState({ loading: false });
          console.log(error);
        });
    }
  };

  render() {
    const { classes } = this.props;
    const { loading, userGuide } = this.state;
    return (
      <form
        className={classes.container}
        noValidate
        autoComplete="off"
        onSubmit={this.submitHandler}
      >
        <div className={classes.root}>
          {loading && (
            <CircularProgress
              className={classes.progress}
              size={200}
              marginLeft="40%"
              color="secondary"
            />
          )}
        </div>
        <Grid container spacing={2} className={classes.gridContainer}>
          <Grid item xl={3} lg={3} md={4} sm={6} xs={12}>
            <TextField
              required
              id="outlined-select-Data-Base-Type"
              select
              label="Test Scripts"
              className={classes.textField}
              name="TestScripts"
              value={this.state.TestScripts}
              SelectProps={{
                native: true,
                MenuProps: { className: classes.menu },
              }}
              margin="normal"
              variant="outlined"
              onChange={this.handleServerTestChange}
            >
              {this.state.currencies.map((currency) => (
                <option key={currency} value={currency}>
                  {currency}
                </option>
              ))}
            </TextField>
          </Grid>
          <Grid item xl={3} lg={3} md={4} sm={6} xs={12}>
            <TextField
              required
              id="outlined-select-Environment"
              select
              label="DB Connection Name"
              className={classes.textField}
              name="env"
              value={this.state.env}
              SelectProps={{
                native: true,
                MenuProps: { className: classes.menu },
              }}
              margin="normal"
              variant="outlined"
              onChange={this.handleServerChange}
            >
              {this.state.Connections.map((currency) => (
                <option key={currency} value={currency}>
                  {currency}
                </option>
              ))}
            </TextField>
          </Grid>
          {/* <Grid item xl={3} lg={3} md={4} sm={6} xs={12}>
            <TextField
              required
              type="number"
              id="outlined-DBRowsStart"
              name="DBRowsStart"
              label="Db Rows Start"
              value={this.state.DBRowsStart}
              className={classes.textField}
              margin="normal"
              variant="outlined"
              onChange={this.handleServerChange}
            />
          </Grid>
          <Grid item xl={3} lg={3} md={4} sm={6} xs={12}>
            <TextField
              type="number"
              id="outlined-DBRowsEnd"
              name="DBRowsEnd"
              label="Db Rows Ebd"
              value={this.state.DBRowsEnd}
              className={classes.textField}
              margin="normal"
              variant="outlined"
              onChange={this.handleServerChange}
            />
          </Grid> */}
          <Grid item xl={3} lg={3} md={4} sm={6} xs={12}>
            <TextField
              required
              id="outlined-email-input"
              label="Email"
              name="email"
              value={this.state.email}
              className={classes.textField}
              type="email"
              autoComplete="email"
              helperText="Please enter your email to get results"
              margin="normal"
              variant="outlined"
              onChange={this.handleServerChange}
            />
          </Grid>
        </Grid>
        <Grid container spacing={2} className={classes.gridContainer}>
          <Grid item xl={3} lg={3} md={4} sm={6} xs={12}>
            <FormControlLabel
              value="schedule"
              control={
                <Checkbox
                  checked={this.state.checked}
                  onChange={this.handleChange}
                  inputProps={{ "aria-label": "controlled" }}
                />
              }
              label="Schedule"
              labelPlacement="end"
            />
          </Grid>
        </Grid>
        {this.state.checked && (
          <Grid container spacing={2} className={classes.gridContainer}>
             <Grid item xl={3} lg={3} md={4} sm={6} xs={12}>
              <TextField
                id="date"
                label="Date?"
                type="date"
                name="date"
                value={this.state.date}
                className={classes.textField}
                defaultValue=""
                margin="normal"
                variant="outlined"
                onChange={this.handleServerChange}
                InputLabelProps={{ shrink: true }}
              
                sx={{ width: 220 }}
              />
            </Grid>
            <Grid item xl={3} lg={3} md={4} sm={6} xs={12}>
              <TextField
                id="time"
                label="Time to Run this?"
                type="time"
                name="time"
                value={this.state.time}
                className={classes.textField}
                defaultValue=""
                margin="normal"
                variant="outlined"
                onChange={this.handleServerChange}
                InputLabelProps={{ shrink: true }}
                inputProps={{
                  step: 300, // 5 min
                }}
                sx={{ width: 220 }}
              />
            </Grid>
            <Grid item xl={3} lg={3} md={4} sm={6} xs={12}>
              <TextField
                required
                id="outlined-select-SQL-Type"
                select
                label="Repeat"
                className={classes.textField}
                name="jobtype"
                value={this.state.jobtype}
                onChange={this.handleServerChange}
                SelectProps={{
                  native: true,
                  MenuProps: { className: classes.menu },
                }}
                margin="normal"
                variant="outlined"
              >
                {JobType.map((option) => (
                  <option key={option.value} value={option.value}>
                    {" "}
                    {option.label}{" "}
                  </option>
                ))}
              </TextField>
            </Grid>
          </Grid>
        )}
        <div
          style={{
            display: "flex",
            alignItems: "center",
            justifyContent: "flex-end",
            width: "100%",
          }}
        >
          {!this.state.checked && (
            <Button
              type="submit"
              text="Submit"
              variant="contained"
              style={{
                marginLeft: "1rem",
                backgroundColor: "#1451B5",
                color: "#fff",
                borderRadius: "64px",
              }}
              disabled={loading}
              // onClick={this.handleSearch}
            >
              Submit
            </Button>
          )}
          {this.state.checked && (
            <Button
              type="submit"
              text="Submit"
              variant="contained"
              style={{
                marginLeft: "1rem",
                backgroundColor: "#1451B5",
                color: "#fff",
                borderRadius: "64px",
              }}
              disabled={loading}
              // onClick={this.handleSearch}
            >
              Schedule
            </Button>
          )}
          <Button
            variant="contained"
            style={{
              marginLeft: "1rem",
              backgroundColor: "gray",
              color: "#fff",
              borderRadius: "64px",
            }}
            type="reset"
            text="Reset"
            onClick={this.resetForm}
            disabled={loading}
          >
            Reset
          </Button>
        </div>
      </form>
    );
  }
}

OutlinedTextFields.propTypes = {
  classes: PropTypes.object.isRequired,
};

const mstp = (state) => {
  return {
    user: state.user,
  };
};

export default connect(mstp, {})(withStyles(styles)(OutlinedTextFields));
