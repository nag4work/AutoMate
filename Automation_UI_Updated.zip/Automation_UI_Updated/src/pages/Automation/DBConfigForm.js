import React, { ActivityIndicator, View, useState } from "react";
import PropTypes from "prop-types";
import { withStyles } from "@material-ui/core/styles";
import Controls from "../../components/controls/Controls";
import TextField from "@material-ui/core/TextField";
import axios from "axios";
import { Grid } from "@material-ui/core";
import CircularProgress from "@material-ui/core/CircularProgress";
import FormControlLabel from "@material-ui/core/FormControlLabel";
import Checkbox from "@material-ui/core/Checkbox";
import { Button } from "@mui/material";
import DBConfigForm from "./DBConfigForm";

const styles = (theme) => ({
  textField: {
    width: "100%",
    //marginLeft: theme.spacing(1),
    //marginRight: theme.spacing(1),
  },
  dense: {
    marginTop: 16,
  },
  menu: {
    width: 1300,
  },
  button: {
    margin: theme.spacing.fullWidth,
  },
  progress: {
    margin: theme.spacing.unit * 25,
    marginLeft: theme.spacing * 50,
    marginRight: theme.spacing * 10,
    left: "23%",
    position: "absolute",
    top: "14vh",
  },
  gridContainer: {
    marginBottom: "1rem",
  },
});

const initialFValues = {
  Port: 0,
  serverName: "",
  DataBaseName: "",
  DBUserName: "",
  DBPassword: "",
  DBType: "",
  Query: "",
  SQLType: "",
  Conditions: "",
  Asserts: "",
  SourceQuery: "",
  date: "",
  time: "",
  jobtype: "",
  TestCaseID: "",
  hireDate: new Date(),
  isPermanent: false,
};

const DBType = [
  { value: "Select", label: "Select.." },
  { value: "Oracle", label: "Oracle" },
  { value: "SQLServer", label: "SQL Server" },
  { value: "SYNAPSE", label: "SYNAPSE" },
  { value: "POSTGRES", label: "POSTGRES" },
  { value: "SNOWFLAKE", label: "SNOWFLAKE" },
  { value: "AWS", label: "AWS" },
  { value: "GCP", label: "GCP" },
];
const envType = [
    { value: "Select", label: "Select.." },
    { value: "DEV", label: "DEV" },
    { value: "UAT", label: "UAT" },
    { value: "PROD", label: "PROD" },
  ];

const SQLType = [
  { value: "Select", label: "Select.." },
  { value: "Count", label: "Count" },
  { value: "Compare", label: "Compare" },
];
const Conditions = [
  { value: "Select", label: "Select.." },
  { value: "Equals", label: "Equals" },
  { value: "Not Equals", label: "Not Equals" },
  { value: "Contains", label: "Contains" },
  { value: "Greater Than", label: "Greater Than" },
  { value: "Less Than", label: "Less Than" },
  { value: "Null", label: "Null" },
  { value: "Not Null", label: "Not Null" },
  { value: "Greater Than or equal to", label: "Greater Than or equal to" },
  { value: "Less Than or equal to", label: "Less Than or equal to" },
  { value: "Match with target Query", label: "Match with target Query" },
];

class OutlinedTextFields extends React.Component {

     crypto = require('crypto');
     
  state = {
    serverName: "",
    Port: "1433",
    DataBaseName: "",
    DBUserName: "",
    DBPassword: "",
    DBType: "",
    env:"",
    ConfigID:'',
    ConfigID_update:'',
    ClientID:crypto.randomUUID(),
    SnowFlakeRole:'',
    SNOWFlake_DB_warehouse:'',
    loading: false,
    userGuide: "",
    dbConfigSubmitted: false,
    Responseflag:false,
    snowflakefields:false,
    response_val:''
  };

  resetForm = () => {
    this.setState({
      
      SQLType: "",
      Conditions: "",
      ConfigID:"",
      ClientID:"",
      Asserts: "",
      env:"",
      SourceQuery: "",
      TargetQuery: "",
      TestCaseID: "",
      email: "@lithia.com",
      
    });
  };

  

  handleChange = (name) => (event) => {
    this.setState({ [name]: event.target.value });
  };


  handleServerChange = (event) => {
    console.log(
      "event",
      event.target.name,
      event.target.value,
      event.target.id
    );
    
    this.setState({ [event.target.name]: event.target.value });
  };

  Snowflakehandler =()=>
  {
      console.log('snowflaje')
      if(this.state.DBType==='SNOWFLAKE')
      {
        this.setState({snowflakefields:true})
      }
      else
      {
        this.setState({snowflakefields:false})
      }
  }

  DBsubmitHandler =()=>
  {

    if(this.state.serverName === "")
       alert("serverName field is required.");
    else if(this.state.Port === "")
        alert("Port field is required.");
    else if(this.state.DataBaseName === "")
        alert("DataBaseName field is required.");
    else if(this.state.DBUserName === "")
        alert("DBUserName field is required.");
    else if(this.state.DBPassword === "")
        alert("DBPassword field is required.");
    else if(this.state.DBType === "")
        alert("DBType field is required.");
        else if(this.state.env === "")
        alert("env field is required.");
        
    else
    {
        if(this.state.DBType === "SNOWFLAKE")
        {
          if(this.state.SnowFlakeRole === "")
          alert("SnowFlakeRole field is required.");
       else if(this.state.SNOWFlake_DB_warehouse === "")
           alert("Snow Flake WareHouse field is required.");
        }
        else
        {
        console.log("dbconfig submitted")
        this.setState({dbConfigSubmitted:true})
        }
    }
  }
  submitHandler = (e) => {
    e.preventDefault();

    if(this.state.serverName === "")
    alert("serverName field is required.");
 else if(this.state.Port === "")
     alert("Port field is required.");
 else if(this.state.DataBaseName === "")
     alert("DataBaseName field is required.");
 else if(this.state.DBUserName === "")
     alert("DBUserName field is required.");
 else if(this.state.DBPassword === "")
     alert("DBPassword field is required.");
 else if(this.state.DBType === "")
     alert("DBType field is required.");
    else if (this.state.Asserts === "")
      alert("Asserts field is required when target Query is blank.");
    else if (this.state.SQLType === "")
      alert("SQLType field is required .");
      else if (this.state.Conditions === "")
      alert("Conditions field is required .");
      else if (this.state.env === "")
      alert("env field is required .");
    else {
        if(this.state.ConfigID === "")
        {
            this.state.ConfigID_update=this.state.DBType+"_"+this.state.DataBaseName+"_"+this.state.DBUserName+"_"+new Date().toISOString();
        }
        else
        {
            this.state.ConfigID_update=this.state.ConfigID
        }
      const postObject = {
        server_name: this.state.serverName,
        configid:this.state.ConfigID_update,
        clientid:this.state.ClientID,
        env:this.state.env,
        port: this.state.Port,
        database_name: this.state.DataBaseName,
        db_UName: this.state.DBUserName,
        db_Password: this.state.DBPassword,
        db_type: this.state.DBType,
        sfdbwarehouse:this.state.SNOWFlake_DB_warehouse,
        sfrole:this.state.SnowFlakeRole,
      };
      var config = {
        headers: {
          Accept: "application/json",
          "Content-Type": "text/plain",
        },
      };

      this.setState({ loading: true });
      alert(
        "Your Request is submitting. You can wait until the Request complete or close the browser"
      );

      axios
        .post(
          "https://app-cvpautomation-dev.azurewebsites.net/Automation/DBConfig",
          //"http://localhost:8080/Automation/DBConfig",
          postObject,
          config
        )
        .then((response) => {
          if (response.status === 200) {
            this.state.response_val="Execution Completed. DB configuration Created with Connection Name:  "+this.state.ConfigID_update;
            this.setState({ loading: false });
            this.setState({ Responseflag: true });
            console.log(response.status);
          }
          else if (response.status === 202) {
            alert(response.data)
            this.setState({ loading: false });
            this.setState({ Responseflag: false });
            console.log(response.status);
          } else {
            this.state.response_val="Request Failed. Please check your input or Contact Admin";
            console.log(response.status);
            this.setState({ loading: false });
            this.setState({ Responseflag: true });
          }
        })
        .catch((error) => {
            this.state.response_val="Request Failed. Please check your input or Contact Admin";
          this.setState({ loading: false });
          this.setState({ Responseflag: true });
          console.log(error);
        });
    }
  };

  render() {
    const { classes } = this.props;
    const { loading, userGuide, dbConfigSubmitted,snowflakefields,Responseflag } = this.state;
   
    return (
      <div>
     <form
        //className={classes.container}
        noValidate
        autoComplete="off"
        onSubmit={this.submitHandler}
      >
        <div className={classes.root}>
          {loading && (
            <CircularProgress
              className={classes.progress}
              size={200}
              marginLeft="40%"
              color="secondary"
            />
          )}
        </div>
        <Grid container spacing={2} className={classes.gridContainer}>
        <Grid item xl={3} lg={13} md={4} sm={6} xs={12}>
            <TextField
            autoFocus
              id="outlined-ConfigId"
              name="ConfigID"
              label="Connection Name"
              
              value={this.state.ConfigID}
              className={classes.textField}
              placeholder={this.state.DBType+"_"+this.state.DataBaseName+"_"+this.state.DBUserName+"_"+new Date().toISOString()}
              variant="outlined"
              helperText="Please enter the valid Unique ID for future reference"
              onChange={this.handleServerChange}
              //autoComplete={this.state.DBType+"_"+this.state.DataBaseName+"_"+this.state.DBUserName+"_"+new Date().toISOString()}
            />
          </Grid>
        
        
          <Grid item xl={3} lg={3} md={4} sm={6} xs={12}>
            <TextField
             disabled
              id="outlined-ClientID"
              required
              name="ClientID"
              label="DataBase Connection ID"
              value={this.state.ClientID}
              className={classes.textField}
              //margin="normal"
              variant="outlined"
              onChange={this.handleServerChange}
              onClick={this.concenate}
            />
          </Grid>
          </Grid>
          <Grid container spacing={2} className={classes.gridContainer}>
          <Grid item xl={3} lg={3} md={4} sm={6} xs={12}>
            <TextField
              required
              id="outlined-select-Data-Base-Type"
              select
              label="DataBase Type"
              className={classes.textField}
              name="DBType"
              value={this.state.DBType}
              SelectProps={{
                native: true,
                MenuProps: { className: classes.menu },
              }}
              //margin="normal"
              variant="outlined"
              onChange={this.handleServerChange}
              onClick={this.Snowflakehandler}
            >
              {DBType.map((option) => (
                <option key={option.value} value={option.value}>
                  {" "}
                  {option.label}{" "}
                </option>
              ))}{" "}
            </TextField>
          </Grid>
          <Grid item xl={3} lg={3} md={4} sm={6} xs={12}>
            <TextField
              required
              id="outlined-select-envType"
              select
              label="Environment"
              className={classes.textField}
              name="env"
              value={this.state.env}
              SelectProps={{
                native: true,
                MenuProps: { className: classes.menu },
              }}
              //margin="normal"
              variant="outlined"
              onChange={this.handleServerChange}
              onClick={this.Snowflakehandler}
            >
              {envType.map((option) => (
                <option key={option.value} value={option.value}>
                  {" "}
                  {option.label}{" "}
                </option>
              ))}{" "}
            </TextField>
          </Grid>
          { !snowflakefields &&
          <Grid item xl={3} lg={3} md={4} sm={6} xs={12}>
            <TextField
              id="outlined-server-name"
              required
              name="serverName"
              label="Server Name"
              value={this.state.serverName}
              className={classes.textField}
              //margin="normal"
              variant="outlined"
              onChange={this.handleServerChange}
            />
          </Grid>}
          { snowflakefields &&
          <Grid item xl={3} lg={3} md={4} sm={6} xs={12}>
            <TextField
              id="outlined-server-name"
              required
              name="serverName"
              label="SnowFlake Host Name"
              value={this.state.serverName}
              className={classes.textField}
              //margin="normal"
              variant="outlined"
              onChange={this.handleServerChange}
            />
          </Grid>}
          { !snowflakefields &&
          <Grid item xl={3} lg={3} md={4} sm={6} xs={12}>
            <TextField
              required
              id="outlined-server-port"
              name="Port"
              label="Port Number"
              value={this.state.Port}
              className={classes.textField}
              //margin="normal"
              variant="outlined"
              onChange={this.handleServerChange}
            />
          </Grid>}
          <Grid item xl={3} lg={3} md={4} sm={6} xs={12}>
            <TextField
              required
              id="outlined-DataBase-name"
              name="DataBaseName"
              label="DataBase Name"
              value={this.state.DataBaseName}
              className={classes.textField}
              //margin="normal"
              variant="outlined"
              onChange={this.handleServerChange}
            />
          </Grid>
          <Grid item xl={3} lg={3} md={4} sm={6} xs={12}>
            <TextField
              required
              id="outlined-DataBase-uname"
              name="DBUserName"
              label="DataBase User Name"
              value={this.state.DBUserName}
              className={classes.textField}
              //margin="normal"
              variant="outlined"
              onChange={this.handleServerChange}
            />
          </Grid>
          <Grid item xl={3} lg={3} md={4} sm={6} xs={12}>
            <TextField
              required
              id="outlined-password-input"
              name="DBPassword"
              label="DB Password"
              value={this.state.DBPassword}
              className={classes.textField}
              type="password"
              autoComplete="current-password"
              //margin="normal"
              variant="outlined"
              onChange={this.handleServerChange}
            />
          </Grid>
          

          {snowflakefields &&    
          <Grid item xl={3} lg={3} md={4} sm={6} xs={12}>
            <TextField
              required
              id="outlined-SnowflakeRole"
              name="SnowFlakeRole"
              label="SnowFlake Role"
              value={this.state.SnowFlakeRole}
              className={classes.textField}
              //margin="normal"
              variant="outlined"
              onChange={this.handleServerChange}
            /></Grid>
            
            
            }
            {snowflakefields &&    
          <Grid item xl={3} lg={3} md={4} sm={6} xs={12}>
            <TextField
              required
              id="outlined-SNOWFlake_DB_warehouse"
              name="SNOWFlake_DB_warehouse"
              label="SnowFlake DB WareHouse"
              value={this.state.SNOWFlake_DB_warehouse}
              className={classes.textField}
              //margin="normal"
              variant="outlined"
              onChange={this.handleServerChange}
            /></Grid>
            
            
            }
            
        </Grid>
        
        <div
          style={{
            display: "flex",
            alignItems: "center",
            justifyContent: "flex-end",
            width: "100%",
          }}
        >
           
       
          <Button
            type="submit"
            text="Submit"
            variant="contained"
            style={{
              marginLeft: "1rem",
              backgroundColor: "#1451B5",
              color: "#fff",
              borderRadius: "64px",
            }}
            disabled={loading}
            onClick={this.DBsubmitHandler}
            
            
          >
            Submit
          </Button>
          
     

          <Button
            variant="contained"
            style={{
              marginLeft: "1rem",
              backgroundColor: "gray",
              color: "#fff",
              borderRadius: "64px",
            }}
            type="reset"
            text="Reset"
            onClick={this.resetForm}
            disabled={loading}
          >
            Reset
          </Button>
        
        </div>
      </form>

      <form>
        <div>{ Responseflag && this.state.response_val}</div>
        
      </form>
      
      </div>

      

      

    );
  }
}

OutlinedTextFields.propTypes = {
  classes: PropTypes.object.isRequired,
};

export default withStyles(styles)(OutlinedTextFields);
