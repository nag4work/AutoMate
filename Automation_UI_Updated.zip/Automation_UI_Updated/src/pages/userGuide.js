import React, { Component } from "react";
import { connect } from "react-redux";
import { withStyles } from "@material-ui/core/styles";
import { userAuth, setFilterOptionsAction } from "../redux/actions/index";
import axios from "axios";
import CircularProgress from "@mui/material/CircularProgress";
import Box from "@mui/material/Box";

const hostUrl = process.env.REACT_APP_HOST ? process.env.REACT_APP_HOST : "";

const styles = (theme) => ({
  root: {
    display: "flex",
    alignItems: "flex-start",
    justifyContent: "center",
    width: "100%",
    height: "91.5%",
    overflow: "hidden",
    background: "#E5E7E9",
  },
});

class UserGuide extends Component {
  constructor(props) {
    super(props);
    this.state = {
      loading: true,
      userGuide: "",
    };
  }
  componentDidMount() {
    //this.getUserGuideUrl();
  }

  // getUserGuideUrl = () => {
  //   const payload = {
  //     key: "userGuideBulkVin",
  //     client: true,
  //   };
  //   axios
  //     .post(`${hostUrl}/api/getConfigData`, payload)
  //     .then((result) => {
  //       const userGuide = result.data.length > 0 ? result.data[0].value : "";
  //       this.setState({ userGuide, loading: false });
  //     })
  //     .catch((err) => {
  //       console.log("Error", err.message);
  //       this.setState({ loading: false });
  //     });
  // };

  render() {
    const { classes } = this.props;
    const { loading, userGuide } = this.state;
    return (
      <div className={classes.root}>
        {loading ? (
          <Box sx={{ display: "flex", alignItems: "center", height: "100%" }}>
            <CircularProgress />
          </Box>
        ) : (
          <iframe
            src={userGuide}
            title="User Guide"
            height="100%"
            width="100%"
          />
        )}
      </div>
    );
  }
}

const mstp = (state) => {
  return {
    user: state.user,
    filterData: state.filterData,
  };
};

export default connect(mstp, { userAuth, setFilterOptionsAction })(
  withStyles(styles, { withTheme: true })(UserGuide)
);
