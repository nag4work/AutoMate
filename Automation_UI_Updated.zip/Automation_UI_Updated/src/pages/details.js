import React, { Component, Suspense } from "react";
import { connect } from "react-redux";
/* Imports from Material MUI */
import { withStyles } from "@material-ui/core/styles";
import { Button } from "@mui/material";
import Tab from "@mui/material/Tab";
import Box from "@mui/material/Box";
import TabContext from "@mui/lab/TabContext";
import TabList from "@mui/lab/TabList";
import TabPanel from "@mui/lab/TabPanel";
// import Autocomplete from "@mui/material/Autocomplete";
// import TextField from "@mui/material/TextField";
// import LocalizationProvider from "@mui/lab/LocalizationProvider";
// import DesktopDateRangePicker from "@mui/lab/DesktopDateRangePicker";
// import AdapterDateFns from "@mui/lab/AdapterDateFns";
import moment from "moment";
import axios from "axios";
import { setHistoryQueryDataAction } from "../redux/actions";
import AutomationForm from "./Automation/AutomationRequestForm2";
import RunScriptsForm from "./Automation/RunExistingScriptsForm";
import ConfigurationForm from "./configForm";
import DBConfig from "./Automation/DBConfigForm";

const styles = (theme) => ({
  root: {
    display: "flex",
    flexDirection: "column",
    alignItems: "left",
    justifyContent: "left",
    //border: "1px solid red",
    margin: "1rem",
    width: "95%",
    height: "85vh",
    fontFamily: `CircularXXWeb,"Segoe UI","Segoe",Tahoma,Helvetica,Arial,sans-seri`,
  },
});

const autoCompleteProps = {
  size: "small",
  variant: "standard",
  //inputProps: {style: { fontSize: "12px"} }, // font size of input text
  InputLabelProps: { style: { fontSize: "12px" } }, // font size of input label
};

const autoProps = {
  size: "small",
  maxHeight: "small",
  limitTags: "1",
  //ChipProps : {{disabled:true}},
  multiple: false,
  //disableCloseOnSelect: true,
  //filterSelectedOptions: true,
  style: { width: "100%" },
  getOptionLabel: (option) => option.user_name,
  renderOption: (props, option, { selected }) => (
    <li {...props} style={{ fontSize: "12px" }}>
      {option.user_name}
    </li>
  ),
};

const autoFileProps = {
  size: "small",
  maxHeight: "small",
  limitTags: "1",
  //ChipProps : {{disabled:true}},
  multiple: false,
  //disableCloseOnSelect: true,
  //filterSelectedOptions: true,
  style: { width: "100%" },
  getOptionLabel: (option) => option.file_name,
  renderOption: (props, option, { selected }) => (
    <li {...props} style={{ fontSize: "12px" }}>
      {option.file_name}
    </li>
  ),
};

class Details extends Component {
  constructor(props) {
    super(props);
    this.state = {
      tabValue: "1",
      userDetails: [],
      userName: {},
      selectedUser: "",
      selectedFile: "",
      filesDetails: [],
      file: {},
      value: [
        moment(Date.now()).subtract(1, "days").format("MM/DD/YYYY"),
        moment(Date.now()).format("MM/DD/YYYY"),
      ],
      searchClicked: false,
      initialLoad: true,
    };
  }
  componentDidMount() {
    // const dateRange = this.props.historyData.dateRange;
    // console.log("url", this.props.location?.search);
    // if (this.props.location?.search) {
    //   this.setState({ value: dateRange, tabValue: "4", searchClicked: true });
    // } else {
    //   this.setState({ value: dateRange, searchClicked: true });
    // }
    //this.fetchUserDetails();
    //this.fetchFileNamesDetails();
  }

  fetchUserDetails = () => {
    axios
      .get("/api/getPgUsersData")
      .then((result) => {
        console.log("result", result.data);
        const userDetails = result.data; //[];
        if (
          userDetails &&
          Array.isArray(userDetails) &&
          userDetails.length > 0
        ) {
          this.setState({
            userDetails,
            userName: {
              user_name: this.props.user.name,
              user_email: this.props.user.email,
              id: this.props.user.id,
            },
            selectedUser: this.props.user.name,
          });
        } else {
          this.setState({
            userDetails: [
              {
                user_name: this.props.user.name,
                user_email: this.props.user.email,
                id: this.props.user.id,
              },
            ],
            userName: {
              user_name: this.props.user.name,
              user_email: this.props.user.email,
              id: this.props.user.id,
            },
            selectedUser: this.props.user.name,
          });
        }
      })
      .catch((err) => {
        console.log("Error fetchUserDetails", err.message);
        this.setState({
          userDetails: [
            {
              user_name: this.props.user.name,
              user_email: this.props.user.email,
              id: this.props.user.id,
            },
          ],
          userName: {
            user_name: this.props.user.name,
            user_email: this.props.user.email,
            id: this.props.user.id,
          },
          selectedUser: this.props.user.name,
        });
      });
  };

  fetchFileNamesDetails = (
    userName = this.props.user.name,
    userEmail = this.props.user.email,
    datesSelected = this.props.historyData.dateRange,
    userId = this.props.user.id
  ) => {
    if (userId && userName && userEmail) {
      console.log("historyData", this.props.historyData, datesSelected);
      //const dateRange = this.props.historyData.dateRange;
      const postObject = {
        userId: userId,
        userName: userName,
        userEmail: userEmail,
        fromDate: datesSelected[0],
        toDate: datesSelected[1],
      };
      axios
        .post("/api/getPgFileNameData", postObject)
        .then((result) => {
          console.log("result", result.data);
          const filesDetails = result.data; //[];
          if (
            filesDetails &&
            Array.isArray(filesDetails) &&
            filesDetails.length > 0
          ) {
            this.setState({
              filesDetails,
              file: {
                file_name: "",
                request_id: "",
              },
              selectedFile: "",
            });
          } else {
            this.setState({
              filesDetails: [
                {
                  file_name: "",
                  request_id: "",
                },
              ],
              file: {
                file_name: "",
                request_id: "",
              },
              selectedFile: "",
            });
          }
        })
        .catch((err) => {
          console.log("Error fetchUserDetails", err.message);
          this.setState({
            filesDetails: [
              {
                file_name: "",
                request_id: "",
              },
            ],
            file: {
              file_name: "",
              request_id: "",
            },
            selectedFile: "",
          });
        });
    }
  };

  handleChange = (event, newValue) => {
    this.setState({ tabValue: newValue });
  };

  handleButtonClick = (newValue) => (e) => {
    this.setState({ tabValue: newValue });
  };

  onUserChange = (e, newValue) => {
    this.setState({ userName: newValue });
  };

  handleDate = (newValues) => {
    console.log("newValues", newValues);
    let value = [];
    value.push(
      moment(newValues[0]).format("MM/DD/YYYY"),
      moment(newValues[1]).format("MM/DD/YYYY")
    );
    console.log("Values", value);
    this.props.setHistoryQueryDataAction({ dateRange: value });
    this.setState({ value });
    this.fetchFileNamesDetails(
      this.state.userName.user_name,
      this.state.userName.user_email,
      value,
      this.state.userName.id
    );
  };

  handleSearch = () => {
    this.setState({ searchClicked: true });
  };

  handleResetSearch = () => {
    this.setState({ searchClicked: false });
  };

  handleResetInitialLoad = () => {
    this.setState({ initialLoad: false });
  };

  render() {
    const { classes } = this.props;
    const {
      value,
      userDetails,
      userName,
      searchClicked,
      selectedUser,
      tabValue,
      initialLoad,
      filesDetails,
      file,
      selectedFile,
    } = this.state;
    return (
      <div className={classes.root}>
        {/* <div
          style={{
            display: "flex",
            alignItems: "center",
            justifyContent: "flex-end",
            width: "100%",
          }}
        >
          <div style={{ display: "flex", width: "15%", marginRight: "1rem" }}>
            <Autocomplete
              id="User"
              {...autoProps}
              options={userDetails}
              value={userName}
              onChange={(event, newValue) => {
                this.fetchFileNamesDetails(
                  newValue?.user_name,
                  newValue?.user_email,
                  value,
                  newValue?.id
                );
                this.setState({ userName: newValue });
              }}
              inputValue={selectedUser}
              onInputChange={(event, newInputValue) => {
                this.setState({ selectedUser: newInputValue });
              }}
              renderInput={(params) => (
                <TextField
                  required
                  {...params}
                  label="User"
                  {...autoCompleteProps}
                  error={!userName && searchClicked}
                  helperText={
                    !userName &&
                    searchClicked &&
                    "Please select a user from list"
                  }
                />
              )}
            />
          </div>
          {tabValue === "2" || tabValue === "3" || tabValue === "5" ? (
            <div style={{ display: "flex", width: "15%", marginRight: "1rem" }}>
              <Autocomplete
                id="FileName"
                {...autoFileProps}
                options={filesDetails}
                value={file}
                onChange={(event, newValue) => {
                  this.setState({ file: newValue });
                }}
                inputValue={selectedFile}
                onInputChange={(event, newInputValue) => {
                  this.setState({ selectedFile: newInputValue });
                }}
                renderInput={(params) => (
                  <TextField
                    {...params}
                    label="File Name"
                    {...autoCompleteProps}
                  />
                )}
              />
            </div>
          ) : null}
          <div
            style={{
              display: "flex",
              alignItems: "center",
              justifyContent: "flex-end",
              width: "35%",
            }}
          >
            <LocalizationProvider dateAdapter={AdapterDateFns}>
              <DesktopDateRangePicker
                startText="Start Date"
                endText="End Date"
                value={value}
                onChange={(newValue) => {
                  this.handleDate(newValue);
                }}
                renderInput={(startProps, endProps) => (
                  <React.Fragment>
                    <TextField
                      required
                      {...startProps}
                      variant="standard"
                      helperText={
                        value[0] === "Invalid date" &&
                        searchClicked &&
                        "Please select valid from date"
                      }
                    />
                    <Box sx={{ mx: 2 }}> to </Box>
                    <TextField
                      required
                      {...endProps}
                      variant="standard"
                      helperText={
                        value[1] === "Invalid date" &&
                        searchClicked &&
                        "Please select valid to date"
                      }
                    />
                  </React.Fragment>
                )}
              />
            </LocalizationProvider>
            <Button
              variant="contained"
              style={{
                marginLeft: "1rem",
                backgroundColor: "#1451B5",
                color: "#fff",
                borderRadius: "64px",
              }}
              onClick={this.handleSearch}
            >
              Search
            </Button>
          </div>
        </div> */}
        <Box sx={{ width: "100%", typography: "body1" }}>
          <TabContext value={this.state.tabValue}>
            <Box sx={{ borderBottom: 1, borderColor: "divider" }}>
              <TabList
                onChange={this.handleChange}
                aria-label="lab API tabs example"
              >
                <Tab label="your Automation" value="1" />
                <Tab label="Execute/Schedule" value="2" />
                <Tab label="Configuration" value="3" />
                {/* <Tab label="Multi Trim" value="3" />
                <Tab label="Error List" value="4" />
                <Tab label="Multi Trim Cache" value="5" /> */}
              </TabList>
            </Box>
            {/* {this.tablePanelSelection(tabValue, value, searchClicked, userName)}*/}
            {tabValue === "1" && (
              <TabPanel
                value="1"
                index="1"
                style={{
                  width: "100%",
                  height: "90%",
                }}
              >
                <AutomationForm />
              </TabPanel>
            )}
            {tabValue === "2" && (
              <TabPanel
                value="2"
                index="2"
                style={{
                  width: "103%",
                  height: "90%",
                }}
              >
                <RunScriptsForm />
              </TabPanel>
            )}
            {tabValue === "3" && (
              <TabPanel
                value="3"
                index="3"
                style={{
                  width: "103%",
                  height: "90%",
                }}
              >
                <DBConfig />
              </TabPanel>
            )}
            {tabValue === "4" && (
              <TabPanel
                value="4"
                index="4"
                style={{
                  width: "103%",
                  height: "90%",
                }}
              >
                <AutomationForm />
              </TabPanel>
            )}
          </TabContext>
        </Box>
      </div>
    );
  }
}

const mstp = (state) => {
  return {
    user: state.user,
    filterData: state.filterData,
    historyData: state.historyData,
  };
};

export default connect(mstp, { setHistoryQueryDataAction })(
  withStyles(styles, { withTheme: true })(Details)
);
