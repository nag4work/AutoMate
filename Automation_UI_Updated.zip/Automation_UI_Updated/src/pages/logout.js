import React, { Component } from "react";
import { connect } from "react-redux";
import Swal from "sweetalert2";
import { withStyles } from "@material-ui/core/styles";
import { userAuth, setFilterOptionsAction } from "../redux/actions/index";
import DrivewayLogo from "./driway.jpg";

const styles = (theme) => ({
  root: {
    flexDirection: "column",
    alignItems: "left",
    justifyContent: "left",
    //border: "1px solid red",
    margin: "1rem",
    width: "95%",
    height: "85vh",
    fontFamily: `CircularXXWeb,"Segoe UI","Segoe",Tahoma,Helvetica,Arial,sans-seri`,
  },
  form: {
    width: "430px",
    //margin: "0 auto",
    display: "flex",
    flexDirection: "column",
    background: "white",
    padding: "20px",
    marginTop: "50px",
    borderRadius: "5px",
  },
  textField: {
    display: "flex",
    width: "100%",
    marginBottom: "0.5rem",
  },
});

class Login extends Component {
  constructor(props) {
    super(props);
    this.state = {};
  }

  componentDidMount() {
    console.log("logout", this.props.user.logout);
    if (this.props.user && this.props.user.logout) {
      Swal.fire({
        position: "center",
        icon: "warning",
        title: `You're currently logged out`,
        text: "Please login to access application",
        showConfirmButton: true,
      });
    }
  }

  render() {
    const { classes } = this.props;
    return (
      <div
        style={{
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          width: "100%",
          height: "90%",
          overflow: "hidden",
          background: "#E5E7E9",
        }}
      >
        <img
          src={DrivewayLogo}
          width="30%"
          height="50%"
          style={{ margin: "auto" }}
          title="You're currently logged out, please login to access the application"
        />
      </div>
    );
  }
}

const mstp = (state) => {
  return {
    user: state.user,
    filterData: state.filterData,
  };
};

export default connect(mstp, { userAuth, setFilterOptionsAction })(
  withStyles(styles, { withTheme: true })(Login)
);
