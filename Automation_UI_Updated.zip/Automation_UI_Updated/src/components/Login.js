import React , { useState }from 'react';
import PropTypes from 'prop-types';
import { withStyles } from '@material-ui/core/styles';
import TextField from '@material-ui/core/TextField';
import Button from '@material-ui/core/Button';
import CircularProgress from "@material-ui/core/CircularProgress";
import {Box} from "@material-ui/core";
import { Grid, } from '@material-ui/core';
import Avatar from "@material-ui/core/Avatar";
import CssBaseline from "@material-ui/core/CssBaseline";
import FormControlLabel from "@material-ui/core/FormControlLabel";
import Checkbox from "@material-ui/core/Checkbox";
import Link from "@material-ui/core/Link";
import LockOutlinedIcon from "@material-ui/icons/LockOutlined";
import Typography from "@material-ui/core/Typography";
import Container from "@material-ui/core/Container";
import Header from "../components/Header";
import CreateScripts from "../pages/Automation/Automation";

const styles = theme => ({
    
 
  textField: {
    marginLeft: theme.spacing(1),
    marginRight:theme.spacing(1),
  },
  dense: {
    marginTop: 16,
  },
  menu: {
    width: 1300,
  },
  button: {
    margin: theme.spacing.fullWidth,
  },
  
});



class OutlinedTextFields extends React.Component {
    state = {
      email: '',
      password: '',
  };
  handleChange = name => event => {
    this.setState({[name]: event.target.value});
  };

 

  handleServerChange = event => {
    this.setState({[ event.target.name]: event.target.value});
  };



  submitHandler ()
    {
      console.log('Testing ');
      alert('testing');
      //const [show, setShow] = useState(false);
   
      //this.props.history.push(Header);
      alert('after testing');
    };

   render() {
    const { classes } = this.props;
    const { loading, userGuide } = this.state;
    return (
      
      <div className={classes.root}>
        {loading ? (
          <Box sx={{ display: "flex", alignItems: "center", height: "100%" }}>
            <CircularProgress />
          </Box>
        ) : (
          <iframe src={userGuide} title="User Guide" height="100%"  width="100%" />
        )}
      </div>
    );
  }

  render() {
    const { classes } = this.props;

    return (

      <Container component="main" maxWidth="xs">
      <CssBaseline />
      <div className={classes.paper}>
        <Avatar className={classes.avatar}>
          <LockOutlinedIcon />
        </Avatar>
        <Typography component="h1" variant="h5">
          Sign in
        </Typography>

      <form    autoComplete="off"  onSubmit={this.submitHandler}>

         <TextField  variant="outlined" margin="normal" required fullWidth id="email" label="User Name" name="email" autoComplete="email" autoFocus value={this.state.email} className={classes.textField}   onChange={this.handleServerChange} />
          <TextField variant="outlined" margin="normal"  required fullWidth name="password"  label="Password" type="password"  id="password" autoComplete="current-password" value={this.state.password} className={classes.textField}    onChange={this.handleServerChange}/>
          <FormControlLabel control={<Checkbox value="remember" color="primary" />} label="Remember me" />

          <Button  type="submit" fullWidth variant="contained" color="primary" className={classes.submit} > Sign In </Button>
             
       
             

      </form>
      </div>
    </Container>
    );
  }
}

OutlinedTextFields.propTypes = {
  classes: PropTypes.object.isRequired,

};

export default withStyles(styles)(OutlinedTextFields);