import React, { Component, useState } from "react";
import ReactDOM from "react-dom";
import MaterialTable from "material-table";
import { forwardRef } from "react";
import AddBox from "@material-ui/icons/AddBox";
import ArrowDownward from "@material-ui/icons/ArrowDownward";
import Check from "@material-ui/icons/Check";
import ChevronLeft from "@material-ui/icons/ChevronLeft";
import ChevronRight from "@material-ui/icons/ChevronRight";
import Clear from "@material-ui/icons/Clear";
import DeleteOutline from "@material-ui/icons/DeleteOutline";
import Edit from "@material-ui/icons/Edit";
import FilterList from "@material-ui/icons/FilterList";
import FirstPage from "@material-ui/icons/FirstPage";
import LastPage from "@material-ui/icons/LastPage";
import Remove from "@material-ui/icons/Remove";
import SaveAlt from "@material-ui/icons/SaveAlt";
import Search from "@material-ui/icons/Search";
import ViewColumn from "@material-ui/icons/ViewColumn";
import DeleteIcon from "@material-ui/icons/Delete";
import SearchIcon from "@material-ui/icons/Search";
import SaveIcon from "@material-ui/icons/Save";
import { Button } from "@material-ui/core";

const TableComponent = ({
  headerColumns,
  tableData,
  isloading,
  noEdit,
  handleUpdate,
  exportFileName,
}) => {
  const [data, setData] = useState(tableData);

  console.log("table Data", tableData, headerColumns, isloading);

  let showOptions = tableData.length > 0;

  const tableIcons = {
    Add: forwardRef((props, ref) => (
      <AddBox {...props} ref={ref} style={{ color: "#1451B5" }} />
    )),
    Check: forwardRef((props, ref) => <Check {...props} ref={ref} />),
    Clear: forwardRef((props, ref) => <Clear {...props} ref={ref} />),
    Delete: forwardRef((props, ref) => <DeleteOutline {...props} ref={ref} />),
    DetailPanel: forwardRef((props, ref) => (
      <ChevronRight {...props} ref={ref} />
    )),
    Edit: forwardRef((props, ref) => {
      if (showOptions && !noEdit) {
        return <Edit {...props} ref={ref} style={{ color: "#1451B5" }} />;
      } else {
        return null;
      }
    }),
    Export: forwardRef((props, ref) => (
      <SaveAlt {...props} ref={ref} style={{ color: "#1451B5" }} />
    )),
    Filter: forwardRef((props, ref) => null), //<FilterList {...props} ref={ref} />),
    FirstPage: forwardRef((props, ref) => <FirstPage {...props} ref={ref} />),
    LastPage: forwardRef((props, ref) => <LastPage {...props} ref={ref} />),
    NextPage: forwardRef((props, ref) => <ChevronRight {...props} ref={ref} />),
    PreviousPage: forwardRef((props, ref) => (
      <ChevronLeft {...props} ref={ref} />
    )),
    ResetSearch: forwardRef((props, ref) => <Clear {...props} ref={ref} />),
    Search: forwardRef((props, ref) => <Search {...props} ref={ref} />),
    SortArrow: forwardRef((props, ref) => (
      <ArrowDownward {...props} ref={ref} style={{ color: "#fff" }} />
    )),
    ThirdStateCheck: forwardRef((props, ref) => (
      <Remove {...props} ref={ref} />
    )),
    ViewColumn: forwardRef((props, ref) => <ViewColumn {...props} ref={ref} />),
  };

  const OptionsToUse = {
    headerStyle: {
      backgroundColor: "#113A7D",
      color: "#FFF",
    },
    maxBodyHeight: "55vh",
    //selection: true,
    search: showOptions,
    filtering: showOptions,
    exportButton: showOptions
      ? {
          csv: showOptions,
          pdf: false,
        }
      : false,
    exportAllData: showOptions,
    sorting: showOptions,
    editable: showOptions,
    actionsColumnIndex: -1,
    paginationPosition: "both", //"top" or "bottom" or "both",
    exportFileName: exportFileName,
  };

  return (
    <MaterialTable
      style={{ width: "100%" }}
      columns={headerColumns}
      data={tableData}
      title=""
      icons={tableIcons}
      isLoading={isloading}
      // actions={[
      //   {
      //     icon: () => <SaveIcon />,
      //     tooltip: "Save User",
      //     onClick: (event, rowData) => alert("You saved " + rowData.name),
      //   },
      // ]}
      // components={{
      //   Action: (props) => (
      //     <Button
      //       onClick={(event) => props.action.onClick(event, props.data)}
      //       color="primary"
      //       variant="text"
      //       style={{ textTransform: "none" }}
      //       size="small"
      //     >
      //       Save
      //     </Button>
      //   ),
      // }}
      options={OptionsToUse}
      localization={{
        pagination: {
          labelDisplayedRows: "{from}-{to} of {count}",
        },
        toolbar: {
          nRowsSelected: "{0} row(s) selected",
        },
        header: {
          actions: "ACTIONS",
        },
        body: {
          emptyDataSourceMessage: "No records to display",
          filterRow: {
            filterTooltip: "Filter",
          },
        },
      }}
      editable={
        !noEdit && {
          // Bulk Update
          onBulkUpdate: (changes) =>
            new Promise((resolve, reject) => {
              setTimeout(() => {
                handleUpdate(changes, "bulk");
                resolve();
              }, 1000);
            }),

          // onRowAdd: (newData) =>
          //   new Promise((resolve, reject) => {
          //     setTimeout(() => {
          //       setData([...data, newData]);

          //       resolve();
          //     }, 1000);
          //   }),
          onRowUpdate: (newData, oldData) =>
            new Promise((resolve, reject) => {
              setTimeout(() => {
                const dataUpdate = [...tableData];
                const index = oldData.tableData.id;
                dataUpdate[index] = newData;
                setData([...dataUpdate]);
                handleUpdate(newData, "single");
                // if (!newData.trim?.includes("|")) {
                //   console.log("Valid Trim", newData.trim);
                // }
                resolve();
              }, 1000);
            }),
          // onRowDelete: (oldData) =>
          //   new Promise((resolve, reject) => {
          //     setTimeout(() => {
          //       const dataDelete = [...tableData];
          //       const index = oldData.tableData.id;
          //       dataDelete.splice(index, 1);
          //       setData([...dataDelete]);

          //       resolve();
          //     }, 1000);
          //   }),
        }
      }
    />
  );
};

export default TableComponent;
