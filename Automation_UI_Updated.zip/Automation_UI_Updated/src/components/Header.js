import React from "react";
import {AppBar,Box,Toolbar,Typography,Tabs,Tab,makeStyles} from '@material-ui/core';
import AdbIcon from "@material-ui/icons/Adb";
import RunScripts from "../pages/Automation/RunExistingScriptsPage";
import CreateScripts from "../pages/Automation/Automation";
import Contact from "../pages/Automation/ContactPage";

const useStyles = makeStyles(theme => ({
    appBar: {
      top: "auto",
      background:'#008394',
      bottom: 0,
      alignItems:"center",
      justify:"center",
      textAlign:"center"
    }
  }));

const ButtonAppBar = props => {
  const { match, history,params,page } = props;
  //const { params } = match;
  //const { page } = params;

  const tabNameToIndex = {
    0: "CreateScripts",
    1: "RunScripts",
    2: "Contact"
  };

  const indexToTabName = {
    CreateScripts: 0,
    RunScripts: 1,
    Contact:2
  };

    const [selectedTab, setSelectedTab] = React.useState(indexToTabName[page]);
    const classes = useStyles();
    const handleChange = (event, newValue) => {
    //history.push(`/home/${tabNameToIndex[newValue]}`);
    setSelectedTab(newValue);
  };

  return (
    
    <>
    <Box >
      <AppBar position="center" className={classes.appBar}>
        <Toolbar  >
        <AdbIcon sx={{ display: { xs: 'none', md: 'flex' }, mr: 10 }} />
             <Typography variant="h3" component="div" sx={{ flexGrow: 10 }}> Automation  </Typography>
             </Toolbar>
      </AppBar>
    </Box>
  
      <AppBar position="static" style={{ background: '#757575' }}>
        <Tabs value={selectedTab} onChange={handleChange}>
          <Tab label="Create your Automation" />
          <Tab label="Run existing Scripts" />
          <Tab label="Contact" />
          <Tab label="User Guide" />
        </Tabs>
      </AppBar>
      {selectedTab === 0 && <CreateScripts />}
      {selectedTab === 1 && <RunScripts />}
      {selectedTab === 2 && <Contact />}
    </>
  );
};

export default ButtonAppBar;

