import React, { useState, useEffect } from "react";
import { connect } from "react-redux";
import clsx from "clsx";
import {
  filterOptionsAction,
  setFilterOptionsAction,
  filterOptionsSelectedAction,
  filterDataAction,
} from "../../redux/actions/index";
import LithiaLogo from "./lithia.png";

import { makeStyles } from "@material-ui/core/styles";
import CssBaseline from "@material-ui/core/CssBaseline";
import Drawer from "@material-ui/core/Drawer";
import AppBar from "@material-ui/core/AppBar";
import Toolbar from "@material-ui/core/Toolbar";
import Divider from "@material-ui/core/Divider";
import Avatar from "@material-ui/core/Avatar";
import { createTheme, ThemeProvider } from "@mui/material/styles";
import IconButton from "@mui/material/IconButton";
import Badge from "@mui/material/Badge";
import { styled } from "@mui/material/styles";
import Tooltip from "@mui/material/Tooltip";
import Logout from "@mui/icons-material/Logout";
import Login from "@mui/icons-material/Login";
import Menu from "@mui/material/Menu";
import MenuItem from "@mui/material/MenuItem";
import { faUser, faHome, faTable } from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { Typography } from "@mui/material";
import Info from "@mui/icons-material/MenuBook";
import Contact from "@mui/icons-material/Info";
import List from "@material-ui/core/List";
import ListItem from "@material-ui/core/ListItem";
import ListItemIcon from "@material-ui/core/ListItemIcon";
import { Link } from "react-router-dom";

const drawerWidth = 400;
const darkTheme = createTheme({
  palette: {
    mode: "dark",
  },
});
const lightTheme = createTheme({
  palette: {
    mode: "light",
  },
});
const useStyles = makeStyles((theme) => ({
  root: {
    display: "flex",
    fontFamily: `CircularXXWeb,"Segoe UI","Segoe",Tahoma,Helvetica,Arial,sans-seri`,
  },
  toolbar: {
    paddingRight: 24, // keep right padding when drawer closed
  },
  title: {
    flexGrow: 1,
  },
  toolbarIcon: {
    display: "flex",
    alignItems: "center",
    justifyContent: "flex-end",
    padding: "0 8px",
    ...theme.mixins.toolbar,
  },
  appBarDark: {
    background: "#E5E7E9",
    zIndex: theme.zIndex.drawer + 1,
    transition: theme.transitions.create(["width", "margin"], {
      easing: theme.transitions.easing.sharp,
      duration: theme.transitions.duration.leavingScreen,
    }),
  },
  appBarShiftDark: {
    background: "#E5E7E9",
    marginLeft: drawerWidth,
    //width: `calc(100% - ${drawerWidth}px)`,
    width: "100%",
    transition: theme.transitions.create(["width", "margin"], {
      easing: theme.transitions.easing.sharp,
      duration: theme.transitions.duration.enteringScreen,
    }),
  },
  appBarLight: {
    background: "#E5E7E9",
    zIndex: theme.zIndex.drawer + 1,
    transition: theme.transitions.create(["width", "margin"], {
      easing: theme.transitions.easing.sharp,
      duration: theme.transitions.duration.leavingScreen,
    }),
  },
  appBarShiftLight: {
    background: "#E5E7E9",
    marginLeft: drawerWidth,
    //width: `calc(100% - ${drawerWidth}px)`,
    width: "100%",
    transition: theme.transitions.create(["width", "margin"], {
      easing: theme.transitions.easing.sharp,
      duration: theme.transitions.duration.enteringScreen,
    }),
  },
  menuButton: {
    marginRight: 36,
  },
  menuButtonHidden: {
    display: "none",
  },
  drawerPaperDark: {
    position: "relative",
    whiteSpace: "nowrap",
    width: drawerWidth,
    transition: theme.transitions.create("width", {
      easing: theme.transitions.easing.sharp,
      duration: theme.transitions.duration.enteringScreen,
    }),
    background: "#1F2121",
    overflowX: "hidden",
  },
  drawerPaperCloseDark: {
    transition: theme.transitions.create("width", {
      easing: theme.transitions.easing.sharp,
      duration: theme.transitions.duration.leavingScreen,
    }),
    /*width : theme.spacing(7),
    [theme.breakpoints.up("sm")]: {
      width: theme.spacing(3),
    } */
    width: 50,
    background: "#1F2121",
    overflowX: "hidden",
  },
  drawerPaperLight: {
    position: "relative",
    whiteSpace: "nowrap",
    width: drawerWidth,
    transition: theme.transitions.create("width", {
      easing: theme.transitions.easing.sharp,
      duration: theme.transitions.duration.enteringScreen,
    }),
    background: "#E5E7E9",
    overflowX: "hidden",
  },
  drawerPaperCloseLight: {
    transition: theme.transitions.create("width", {
      easing: theme.transitions.easing.sharp,
      duration: theme.transitions.duration.leavingScreen,
    }),
    /*width : theme.spacing(7),
    [theme.breakpoints.up("sm")]: {
      width: theme.spacing(3),
    } */
    width: 50,
    background: "#E5E7E9",
    overflowX: "hidden",
  },
  appBarSpacer: theme.mixins.toolbar,
  content: {
    flexGrow: 1,
    height: "100vh",
    overflow: "auto",
    //padding: "2rem",
  },
  container: {
    paddingTop: theme.spacing(4),
    paddingBottom: theme.spacing(4),
  },
  paper: {
    padding: theme.spacing(2),
    display: "flex",
    overflow: "auto",
    flexDirection: "column",
  },
  fixedHeight: {
    height: 40,
  },
  selectDrawerIcon: {
    borderLeft: "4px solid #fff",
    background: "rgba(0,0,0,0.3) !important",
    height: "50px",
  },
  drawerIcon: {
    marginLeft: "4px",
    height: "50px",
  },
  listItemText: {
    display: "flex",
    color: "#FFFFFF",
    fontWeight: 400,
    fontSize: "16px",
    paddingLeft: "0.25rem",
  },
  title: {
    display: "flex",
    color: "#000",
    fontSize: "16px",
    alignItems: "center",
    paddingLeft: "0.25rem",
    fontFamily: `CircularXXWeb,"Segoe UI","Segoe",Tahoma,Helvetica,Arial,sans-seri`,
    fontWeight: "bold",
  },
  user: {
    fontSize: "12px",
    color: "#000",
    display: "flex",
    alignItems: "center",
    paddingRight: "0.50rem",
  },
  drawerToolbar: {
    display: "flex",
    alignItems: "center",
    justifyContent: "flex-start",
    padding: "0 8px",
    height: theme.spacing(7),
  },
}));

const StyledBadgeLogin = styled(Badge)(({ theme }) => ({
  "& .MuiBadge-badge": {
    backgroundColor: "#1451B5",
    color: "#1451B5",
    boxShadow: `0 0 0 2px ${theme.palette.background.paper}`,
    "&::after": {
      position: "absolute",
      top: 0,
      left: 0,
      width: "100%",
      height: "100%",
      borderRadius: "50%",
      animation: "ripple 1.2s infinite ease-in-out",
      border: "1px solid currentColor",
      content: '""',
    },
  },
  "@keyframes ripple": {
    "0%": {
      transform: "scale(.8)",
      opacity: 1,
    },
    "100%": {
      transform: "scale(2.4)",
      opacity: 0,
    },
  },
}));

const StyledBadgeLogOff = styled(Badge)(({ theme }) => ({
  "& .MuiBadge-badge": {
    backgroundColor: "#CACFD2",
    color: "#CACFD2",
    boxShadow: `0 0 0 2px ${theme.palette.background.paper}`,
    "&::after": {
      position: "absolute",
      top: 0,
      left: 0,
      width: "100%",
      height: "100%",
      borderRadius: "50%",
      animation: "ripple 1.2s infinite ease-in-out",
      border: "1px solid currentColor",
      content: '""',
    },
  },
  "@keyframes ripple": {
    "0%": {
      transform: "scale(.8)",
      opacity: 1,
    },
    "100%": {
      transform: "scale(2.4)",
      opacity: 0,
    },
  },
}));

const hostUrl = process.env.REACT_APP_HOST ? process.env.REACT_APP_HOST : "";

export function Navigation(props) {
  const classes = useStyles();
  const history = props.history;
  const [lightMode, setLightMode] = useState(false);
  const [open, setOpen] = useState(false);
  const [selectedIndex, setSelectionIndex] = useState(0);
  const [filterOptions, setFilterOptions] = useState(
    props.metaData.filterOptions
  );

  //Logoff menu
  const [anchorEl, setAnchorEl] = useState(null);
  const openMenu = Boolean(anchorEl);

  const upperDrawerSection = [
    { label: "Home", kind: faHome, to: "/" },
    { label: "Stats", kind: faTable, to: "/stats" },
  ];

  const handleListItemClick = (event, index) => {
    console.log("Selected Index", selectedIndex, index);
    setSelectionIndex(index);
  };

  const handleClick = (event) => {
    setAnchorEl(event.currentTarget);
  };
  const handleClose = () => {
    setAnchorEl(null);
  };

  const handleLogin = () => {
    //reset all props
    const userObj = {
      id: "",
      name: "",
      email: "",
      login: true,
      logout: false,
    };
    props.setFilterOptionsAction(userObj);
    history.push("/login");
  };

  const handleLogOff = () => {
    //reset all props
    const userObj = {
      id: "",
      name: "",
      email: "",
      login: false,
      logout: true,
    };
    props.setFilterOptionsAction(userObj);
    setOpen(false); //drawer close
    setSelectionIndex(0);
    history.push("/logout");
  };

  //const history = createBrowserHistory();
  const handleDrawer = () => {
    setOpen(!open);
  };

  const handleThemeMode = () => {
    setLightMode(!lightMode);
  };

  //componentDidMount
  useEffect(() => {
    const pathName = window.location.pathname;
    checkForUserDetails();
    const index = pathName === "/stats" ? 1 : 0;
    setSelectionIndex(index);
  }, []);

  const navigateToHome = () => {
    //return null;
    console.log("history", history);
    //props.children[0]._self.props.history.push("/");
    if (
      props.user.name.trim() === "" ||
      props.user.email.trim() === "" ||
      props.user.id === ""
    ) {
      history.push("/login");
    } else {
      history.push("/");
    }
  };

  const checkForUserDetails = () => {
    if (
      props.user.name.trim() === "" ||
      props.user.email.trim() === "" ||
      props.user.id === "" ||
      props.user.expiry
    ) {
      console.log("user login", props.user.name);
      setSelectionIndex(0);
      history.push("/login");
    }
  };

  const navigateToUserGuide = () => {
    history.push("/userGuide");
  };

  const navigateToContactForm = () => {
    history.push("/contactForm");
  };

  return (
    <div className={classes.root}>
      <CssBaseline />
      <AppBar
        position="absolute"
        //className={clsx(classes.appBar, open && classes.appBarShift)}
        className={
          !lightMode
            ? clsx(classes.appBarDark, open && classes.appBarShiftDark)
            : clsx(classes.appBarLight, open && classes.appBarShiftLight)
        }
      >
        <Toolbar className={classes.toolbar}>
          <div
            style={{
              display: "flex",
              flexDirection: "row",
              justifyContent: "space-between",
              alignItems: "left",
              width: "100%",
              height: "65px",
            }}
          >
            <div
              style={{
                display: "flex",
                flexDirection: "row",
                width: "34%",
                height: "65px",
                alignItems: "center",
              }}
            >
              <IconButton
                color="primary"
                aria-label="Home"
                onClick={navigateToHome}
              >
                <img
                  alt=""
                  style={{
                    width: "40px",
                    height: "30px",
                  }}
                  src={LithiaLogo}
                />
                <div className={classes.title}>Automation UI</div>
              </IconButton>
            </div>

            <div
              style={{
                boxSizing: "border-box",
                display: "flex",
                flexDirection: "row",
                alignItems: "center",
                justifyContent: "flex-end",
                paddingLeft: "1rem",
                height: "65px",
                width: "20%",
              }}
            >
              {props.user && props.user.name.trim().length > 0 && (
                <>
                  <div>
                    <IconButton
                      color="primary"
                      aria-label="UserGuide"
                      onClick={navigateToUserGuide}
                    >
                      <Info
                        color="primary"
                        fontSize="large"
                        titleAccess="User Guide"
                        style={{ color: "#1451B5" }}
                      />
                    </IconButton>
                  </div>
                  <div>
                    <IconButton
                      color="primary"
                      aria-label="ContactFom"
                      onClick={navigateToContactForm}
                    >
                      <Contact
                        color="primary"
                        fontSize="large"
                        titleAccess="Contact Form"
                        style={{ color: "#1451B5" }}
                      />
                    </IconButton>
                  </div>
                </>
              )}
              <div
                style={{
                  display: "flex",
                  flexDirection: "row",
                  borderLeft: "1px solid #99A3A4",
                  paddingLeft: "1rem",
                  alignItems: "center",
                }}
              >
                <div className={classes.user}>
                  <Typography
                    variant="string"
                    style={{ textTransform: "capitalize" }}
                  >
                    {props.user && props.user.name}
                  </Typography>
                </div>

                <Tooltip title="Login/Logout">
                  <IconButton
                    onClick={handleClick}
                    size="small"
                    sx={{ ml: 2 }}
                    aria-controls={openMenu ? "account-menu" : undefined}
                    aria-haspopup="true"
                    aria-expanded={openMenu ? "true" : undefined}
                  >
                    {props.user && props.user.name.trim().length > 0 ? (
                      <StyledBadgeLogin
                        overlap="circular"
                        anchorOrigin={{
                          vertical: "bottom",
                          horizontal: "right",
                        }}
                        variant="dot"
                      >
                        <Avatar>
                          <FontAwesomeIcon
                            size="xs"
                            icon={faUser}
                            style={{ color: "#000" }}
                          />
                        </Avatar>
                      </StyledBadgeLogin>
                    ) : (
                      <StyledBadgeLogOff
                        overlap="circular"
                        anchorOrigin={{
                          vertical: "bottom",
                          horizontal: "right",
                        }}
                        variant="dot"
                      >
                        <Avatar>
                          <FontAwesomeIcon
                            size="xs"
                            icon={faUser}
                            style={{ color: "#000" }}
                          />
                        </Avatar>
                      </StyledBadgeLogOff>
                    )}
                  </IconButton>
                </Tooltip>
              </div>
            </div>
          </div>
        </Toolbar>
      </AppBar>

      {/* <ThemeProvider theme={lightMode ? lightTheme : darkTheme}>
        <Drawer
          variant="permanent"
          classes={
            !lightMode
              ? {
                  paper: clsx(
                    classes.drawerPaperDark,
                    !open && classes.drawerPaperCloseDark
                  ),
                }
              : {
                  paper: clsx(
                    classes.drawerPaperLight,
                    !open && classes.drawerPaperCloseLight
                  ),
                }
          }
          open={open}
        >
          <div className={classes.drawerToolbar}></div>
          <List>
            {upperDrawerSection.map((item, index) => {
              return (
                <ListItem
                  key={item.label}
                  button
                  component={Link}
                  to={item.to}
                  className={
                    selectedIndex === index
                      ? classes.selectDrawerIcon
                      : classes.drawerIcon
                  }
                  onClick={(event) => handleListItemClick(event, index)}
                  selected={selectedIndex === index}
                >
                  <ListItemIcon
                    style={{
                      onMouseOver: {
                        boderLeft: "4px",
                        borderLeftStyle: "solid",
                        background: "rgba(0,0,0,0.3) !important",
                      },
                    }}
                  >
                    <FontAwesomeIcon
                      size="lg"
                      icon={item.kind}
                      style={{ color: "#FFFFFF" }}
                    />
                  </ListItemIcon>
                  <div className={classes.listItemText}>{item.label}</div>
                </ListItem>
              );
            })}
          </List>
          <Divider />
        </Drawer>
      </ThemeProvider> */}

      <Menu
        anchorEl={anchorEl}
        id="account-menu"
        open={openMenu}
        onClose={handleClose}
        onClick={handleClose}
        PaperProps={{
          elevation: 0,
          sx: {
            overflow: "visible",
            filter: "drop-shadow(0px 2px 8px rgba(0,0,0,0.32))",
            mt: 1.5,
            "& .MuiAvatar-root": {
              width: 32,
              height: 32,
              ml: -0.5,
              mr: 1,
            },
            "&:before": {
              content: '""',
              display: "block",
              position: "absolute",
              top: 0,
              right: 14,
              width: 10,
              height: 10,
              bgcolor: "background.paper",
              transform: "translateY(-50%) rotate(45deg)",
              zIndex: 0,
            },
          },
        }}
        transformOrigin={{ horizontal: "right", vertical: "top" }}
        anchorOrigin={{ horizontal: "right", vertical: "bottom" }}
      >
        {props.user && props.user.name.trim().length > 0 && (
          <MenuItem onClick={handleLogOff}>
            <ListItemIcon>
              <Logout fontSize="small" />
            </ListItemIcon>
            Logout
          </MenuItem>
        )}
        {props.user && props.user.name.trim().length === 0 && (
          <MenuItem onClick={handleLogin}>
            <ListItemIcon>
              <Login fontSize="small" />
            </ListItemIcon>
            Login
          </MenuItem>
        )}
      </Menu>
      <main className={classes.content}>
        <div className={classes.appBarSpacer} />
        {props.children}
      </main>
    </div>
  );
}

const mstp = (state) => {
  return {
    user: state.user,
    metaData: state.metaData,
    selectedMetaData: state.selectedMetaData,
    filterData: state.filterData,
  };
};

export default connect(mstp, {
  filterOptionsAction,
  setFilterOptionsAction,
  filterDataAction,
  filterOptionsSelectedAction,
})(Navigation);
