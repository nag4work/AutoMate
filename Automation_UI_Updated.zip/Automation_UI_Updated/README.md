# Introduction

## Automation UI Project

# Getting Started

- Run `npm i --legacy-peer-deps`
- Run `npm start`

# Build and Test

# Contribute

- `Aravind Rao Gone, aravindgone@lithia.com`
